# ⚡ Vitality AI - Python Desktop App

## Setup & Run

### 1. Install dependency
pip install requests

### 2. Add your API key
Open vitality_ai.py → line 8 → replace PASTE_YOUR_KEY_HERE with your key:
API_KEY = "sk-ant-api03-..."

### 3. Run the app
python vitality_ai.py

## Features
- 🏠 Dashboard with calorie tracker
- 📷 Food Scanner with nutrition info
- 🏋️ Live Workout Tracker with timer
- 📚 Exercise Library with filters
- 🧠 AI Nutrition Coach (Claude AI)
- 🏗 Custom Routine Builder

## Requirements
- Python 3.8+
- tkinter (built into Python)
- requests library
