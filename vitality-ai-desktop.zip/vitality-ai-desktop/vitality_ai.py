import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import requests
import json
import threading
import time
import random

# ── CONFIG ──
API_KEY = "PASTE_YOUR_KEY_HERE"  # ← Paste your sk-ant-... key here
API_URL = "https://api.anthropic.com/v1/messages"
MODEL   = "claude-sonnet-4-20250514"

# ── COLORS ──
BG      = "#0D0F0A"
BG2     = "#141710"
CARD    = "#1A1E14"
CARD2   = "#222818"
LIME    = "#C8F135"
MUTED   = "#6B7355"
TEXT    = "#E8EDDA"
TEXT2   = "#A8B090"
RED     = "#FF5C5C"
ORANGE  = "#FF9B42"
TEAL    = "#3CFFD0"
BORDER  = "#2A3020"

# ── FOOD DATABASE ──
FOODS = {
    "chicken": {"name": "Grilled Chicken Breast", "kcal": 165, "protein": "31g", "fat": "3.6g", "carbs": "0g"},
    "rice":    {"name": "Brown Rice (cooked)",    "kcal": 216, "protein": "5g",  "fat": "1.8g", "carbs": "45g"},
    "egg":     {"name": "Scrambled Eggs (2)",     "kcal": 182, "protein": "12g", "fat": "14g",  "carbs": "2g"},
    "banana":  {"name": "Banana (Medium)",        "kcal": 89,  "protein": "1.1g","fat": "0.3g", "carbs": "23g"},
    "oats":    {"name": "Overnight Oats",         "kcal": 380, "protein": "14g", "fat": "8g",   "carbs": "62g"},
    "salad":   {"name": "Caesar Salad",           "kcal": 220, "protein": "8g",  "fat": "14g",  "carbs": "18g"},
    "yogurt":  {"name": "Greek Yogurt",           "kcal": 130, "protein": "17g", "fat": "4g",   "carbs": "9g"},
    "apple":   {"name": "Apple (Medium)",         "kcal": 95,  "protein": "0.5g","fat": "0.3g", "carbs": "25g"},
}

EXERCISES = [
    ("Barbell Bench Press", "Chest",     "Intermediate", "4x8-12"),
    ("Push-Up Variations",  "Full Body", "Beginner",     "3x15-20"),
    ("Overhead Press",      "Shoulders", "Intermediate", "4x8-10"),
    ("Tricep Pushdown",     "Arms",      "Beginner",     "3x12-15"),
    ("Pull-Ups",            "Back",      "Intermediate", "4x6-10"),
    ("Barbell Squat",       "Legs",      "Beginner",     "4x8-12"),
    ("Deadlift",            "Back",      "Advanced",     "3x5"),
    ("Cable Flyes",         "Chest",     "Beginner",     "3x15"),
    ("Bicep Curls",         "Arms",      "Beginner",     "3x12"),
    ("Plank Hold",          "Core",      "Beginner",     "3x60s"),
    ("Leg Press",           "Legs",      "Beginner",     "4x10-12"),
    ("Lateral Raises",      "Shoulders", "Beginner",     "3x15"),
]

class VitalityAI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("⚡ Vitality AI")
        self.root.geometry("480x760")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)

        self.meals = [
            {"emoji": "🥣", "name": "Overnight Oats",       "time": "7:30 AM · Breakfast", "kcal": 380},
            {"emoji": "🥗", "name": "Grilled Chicken Salad", "time": "12:45 PM · Lunch",    "kcal": 520},
            {"emoji": "🍎", "name": "Apple + Almonds",       "time": "3:00 PM · Snack",     "kcal": 210},
        ]
        self.chat_history = []
        self.timer_sec = 24 * 60 + 18
        self.timer_running = False
        self.current_screen = None

        self.setup_styles()
        self.build_main()
        self.show_screen("home")

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=CARD, foreground=TEXT2,
                        padding=[12, 6], font=("Segoe UI", 9))
        style.map("TNotebook.Tab", background=[("selected", LIME)],
                  foreground=[("selected", BG)])
        style.configure("Treeview", background=CARD, foreground=TEXT,
                        fieldbackground=CARD, rowheight=32, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", background=CARD2, foreground=LIME,
                        font=("Segoe UI", 9, "bold"))
        style.map("Treeview", background=[("selected", LIME)],
                  foreground=[("selected", BG)])

    def build_main(self):
        # ── Header ──
        self.header = tk.Frame(self.root, bg=BG2, height=56)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)

        tk.Label(self.header, text="⚡ Vitality AI", bg=BG2, fg=LIME,
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=16, pady=12)

        self.header_sub = tk.Label(self.header, text="", bg=BG2, fg=MUTED,
                                   font=("Segoe UI", 9))
        self.header_sub.pack(side="right", padx=16)

        # ── Nav tabs ──
        self.nav = tk.Frame(self.root, bg=BG2, height=48)
        self.nav.pack(fill="x")
        self.nav.pack_propagate(False)

        self.nav_btns = {}
        tabs = [("🏠 Home","home"), ("📷 Scan","scan"), ("🏋️ Workout","workout"),
                ("📚 Library","library"), ("🧠 Coach","coach")]
        for label, key in tabs:
            btn = tk.Button(self.nav, text=label, bg=BG2, fg=MUTED,
                           font=("Segoe UI", 8), bd=0, cursor="hand2",
                           command=lambda k=key: self.show_screen(k),
                           activebackground=BG2, activeforeground=LIME,
                           padx=6)
            btn.pack(side="left", fill="y", expand=True)
            self.nav_btns[key] = btn

        # ── Content area ──
        self.content = tk.Frame(self.root, bg=BG)
        self.content.pack(fill="both", expand=True)

        # ── Status bar ──
        self.status = tk.Label(self.root, text="✅ Ready", bg=BG2, fg=MUTED,
                               font=("Segoe UI", 8), anchor="w")
        self.status.pack(fill="x", side="bottom")

        # Build all screens
        self.screens = {}
        self.build_home()
        self.build_scan()
        self.build_workout()
        self.build_library()
        self.build_coach()

    def show_screen(self, name):
        for s in self.screens.values():
            s.pack_forget()
        self.screens[name].pack(fill="both", expand=True)
        self.current_screen = name

        # Update nav highlight
        for k, btn in self.nav_btns.items():
            btn.config(fg=LIME if k == name else MUTED,
                       bg="#1A1E14" if k == name else BG2)

        labels = {"home":"Dashboard","scan":"Food Scanner","workout":"Workout Tracker",
                  "library":"Exercise Library","coach":"AI Nutrition Coach"}
        self.header_sub.config(text=labels.get(name, ""))

        if name == "workout" and not self.timer_running:
            self.start_timer()

    def card(self, parent, **kwargs):
        f = tk.Frame(parent, bg=CARD, bd=0, highlightthickness=1,
                     highlightbackground=BORDER, **kwargs)
        return f

    def label(self, parent, text, size=10, color=TEXT, bold=False, **kwargs):
        font = ("Segoe UI", size, "bold" if bold else "normal")
        return tk.Label(parent, text=text, bg=parent["bg"], fg=color,
                        font=font, **kwargs)

    def btn(self, parent, text, cmd, bg=LIME, fg=BG, size=10):
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                        font=("Segoe UI", size, "bold"), bd=0, cursor="hand2",
                        activebackground=CARD2, activeforeground=LIME,
                        padx=10, pady=8, relief="flat")

    def set_status(self, msg):
        self.status.config(text=f"  {msg}")

    # ══════════════════════════════════════
    # SCREEN: HOME
    # ══════════════════════════════════════
    def build_home(self):
        frame = tk.Frame(self.content, bg=BG)
        self.screens["home"] = frame

        canvas = tk.Canvas(frame, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)

        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Greeting
        greet = self.card(inner)
        greet.pack(fill="x", padx=12, pady=(12, 6))
        self.label(greet, "Good Morning, Alex 👋", 14, LIME, True).pack(anchor="w", padx=12, pady=(10,2))
        self.label(greet, "340 kcal remaining today", 9, MUTED).pack(anchor="w", padx=12, pady=(0,10))

        # Calorie ring (simulated with progress bar)
        cal_card = self.card(inner)
        cal_card.pack(fill="x", padx=12, pady=6)
        top = tk.Frame(cal_card, bg=CARD)
        top.pack(fill="x", padx=12, pady=(10,4))
        self.label(top, "Today's Calories", 10, TEXT2).pack(side="left")
        self.total_kcal_lbl = self.label(top, "1,460 / 1,800 kcal", 10, LIME, True)
        self.total_kcal_lbl.pack(side="right")

        self.cal_bar = ttk.Progressbar(cal_card, value=81, maximum=100,
                                        style="green.Horizontal.TProgressbar")
        self.cal_bar.pack(fill="x", padx=12, pady=(0,8))

        # Style progress bar
        s = ttk.Style()
        s.configure("green.Horizontal.TProgressbar", troughcolor=BORDER,
                     background=LIME, thickness=12)

        macro = tk.Frame(cal_card, bg=CARD)
        macro.pack(fill="x", padx=12, pady=(0,10))
        for label, val, color in [("Protein","82g",LIME),("Carbs","164g",TEAL),("Fats","48g",ORANGE)]:
            m = tk.Frame(macro, bg=CARD2, padx=10, pady=6)
            m.pack(side="left", expand=True, fill="x", padx=3)
            tk.Label(m, text=val, bg=CARD2, fg=color, font=("Segoe UI",11,"bold")).pack()
            tk.Label(m, text=label, bg=CARD2, fg=MUTED, font=("Segoe UI",8)).pack()

        # Quick actions
        self.label(inner, "Quick Actions", 11, TEXT, True).pack(anchor="w", padx=16, pady=(10,4))
        qa = tk.Frame(inner, bg=BG)
        qa.pack(fill="x", padx=12, pady=(0,6))
        actions = [("📷 Scan Food","scan",LIME,BG),("🏋️ Workout","workout",CARD2,LIME),
                   ("🧠 AI Coach","coach",CARD2,TEAL),("🗓 Schedule","schedule",CARD2,ORANGE)]
        for i, (lbl, scr, bg, fg) in enumerate(actions):
            b = tk.Button(qa, text=lbl, bg=bg, fg=fg, font=("Segoe UI",9,"bold"),
                         bd=0, cursor="hand2", padx=8, pady=10,
                         command=lambda s=scr: self.show_screen(s) if s in self.screens else self.set_status(f"Opening {s}..."),
                         relief="flat", highlightthickness=1, highlightbackground=BORDER)
            b.grid(row=i//2, column=i%2, padx=4, pady=4, sticky="ew")
        qa.columnconfigure(0, weight=1)
        qa.columnconfigure(1, weight=1)

        # Meal log
        self.label(inner, "Today's Meals", 11, TEXT, True).pack(anchor="w", padx=16, pady=(10,4))
        self.meal_frame = tk.Frame(inner, bg=BG)
        self.meal_frame.pack(fill="x", padx=12, pady=(0,6))
        self.render_meals()

        # Add meal button
        add_row = tk.Frame(inner, bg=BG)
        add_row.pack(fill="x", padx=12, pady=(0,12))
        self.btn(add_row, "+ Add Meal", self.open_add_meal).pack(side="left")
        self.btn(add_row, "📊 Nutrition Insights", lambda: self.show_screen("coach"),
                 bg=CARD2, fg=TEAL).pack(side="right")

    def render_meals(self):
        for w in self.meal_frame.winfo_children():
            w.destroy()
        total = sum(m["kcal"] for m in self.meals)
        self.total_kcal_lbl.config(text=f"{total:,} / 1,800 kcal")
        self.cal_bar["value"] = min(100, int(total / 1800 * 100))

        for m in self.meals:
            row = self.card(self.meal_frame)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=m["emoji"], bg=CARD, font=("Segoe UI",18)).pack(side="left", padx=10, pady=8)
            info = tk.Frame(row, bg=CARD)
            info.pack(side="left", fill="both", expand=True, pady=8)
            tk.Label(info, text=m["name"], bg=CARD, fg=TEXT, font=("Segoe UI",10,"bold"), anchor="w").pack(anchor="w")
            tk.Label(info, text=m["time"], bg=CARD, fg=MUTED, font=("Segoe UI",8), anchor="w").pack(anchor="w")
            tk.Label(row, text=f"{m['kcal']} kcal", bg=CARD, fg=LIME,
                    font=("Segoe UI",10,"bold")).pack(side="right", padx=12)

    def open_add_meal(self):
        win = tk.Toplevel(self.root)
        win.title("Add Meal")
        win.geometry("360x320")
        win.configure(bg=BG)
        win.grab_set()

        tk.Label(win, text="Add Food to Meal Log", bg=BG, fg=LIME,
                font=("Segoe UI",13,"bold")).pack(pady=(16,10))

        fields = [("Food Name", ""), ("Calories (kcal)", ""), ("Time/Meal", "Dinner")]
        entries = {}
        for lbl, default in fields:
            tk.Label(win, text=lbl, bg=BG, fg=TEXT2, font=("Segoe UI",9)).pack(anchor="w", padx=20)
            e = tk.Entry(win, bg=CARD2, fg=TEXT, font=("Segoe UI",10),
                        insertbackground=LIME, relief="flat", bd=0,
                        highlightthickness=1, highlightbackground=BORDER)
            e.insert(0, default)
            e.pack(fill="x", padx=20, pady=(2,8), ipady=6)
            entries[lbl] = e

        def add():
            name = entries["Food Name"].get().strip()
            try: kcal = int(entries["Calories (kcal)"].get())
            except: kcal = 0
            meal_time = entries["Time/Meal"].get().strip()
            if name:
                self.meals.append({"emoji":"🍽️","name":name,"time":f"Just now · {meal_time}","kcal":kcal})
                self.render_meals()
                self.set_status(f"✅ Added: {name}")
                win.destroy()
            else:
                messagebox.showwarning("Missing Info", "Please enter a food name!")

        self.btn(win, "✅ Add to Meal Log", add).pack(pady=8, padx=20, fill="x")

    # ══════════════════════════════════════
    # SCREEN: FOOD SCANNER
    # ══════════════════════════════════════
    def build_scan(self):
        frame = tk.Frame(self.content, bg=BG)
        self.screens["scan"] = frame

        self.label(frame, "🔍 AI Food Scanner", 14, LIME, True).pack(pady=(20,4))
        self.label(frame, "Type a food name to get instant nutrition info", 9, MUTED).pack()

        search_frame = tk.Frame(frame, bg=BG)
        search_frame.pack(fill="x", padx=20, pady=16)

        self.scan_entry = tk.Entry(search_frame, bg=CARD2, fg=TEXT,
                                   font=("Segoe UI",12), insertbackground=LIME,
                                   relief="flat", bd=0, highlightthickness=1,
                                   highlightbackground=LIME)
        self.scan_entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0,8))
        self.scan_entry.insert(0, "e.g. chicken, rice, egg...")
        self.scan_entry.bind("<FocusIn>", lambda e: self.scan_entry.delete(0,"end") if "e.g." in self.scan_entry.get() else None)
        self.scan_entry.bind("<Return>", lambda e: self.do_scan())

        self.btn(search_frame, "📷 Scan", self.do_scan).pack(side="right")

        # Result card
        self.scan_result = self.card(frame)
        self.scan_result.pack(fill="x", padx=20, pady=8)

        self.scan_title = self.label(self.scan_result, "Enter a food above to scan", 12, TEXT2)
        self.scan_title.pack(pady=(14,4), padx=14)

        self.scan_conf = self.label(self.scan_result, "", 9, TEAL)
        self.scan_conf.pack(padx=14)

        nutr = tk.Frame(self.scan_result, bg=CARD)
        nutr.pack(fill="x", padx=14, pady=10)
        self.nutr_labels = {}
        for i, (key, color) in enumerate([("kcal",LIME),("protein",TEAL),("fat",ORANGE),("carbs",TEXT)]):
            box = tk.Frame(nutr, bg=CARD2, padx=8, pady=8,
                          highlightthickness=1, highlightbackground=BORDER)
            box.grid(row=0, column=i, padx=3, sticky="ew")
            v = tk.Label(box, text="--", bg=CARD2, fg=color, font=("Segoe UI",14,"bold"))
            v.pack()
            tk.Label(box, text=key, bg=CARD2, fg=MUTED, font=("Segoe UI",8)).pack()
            self.nutr_labels[key] = v
        for i in range(4):
            nutr.columnconfigure(i, weight=1)

        self.btn(self.scan_result, "+ Add to Meal Log", self.add_scanned_meal,
                 bg=LIME, fg=BG).pack(pady=(4,14), padx=14, fill="x")

        # Popular foods
        self.label(frame, "Popular Foods", 11, TEXT, True).pack(anchor="w", padx=20, pady=(16,6))
        pop = tk.Frame(frame, bg=BG)
        pop.pack(fill="x", padx=20)
        for i, food in enumerate(["chicken","rice","egg","banana","oats","yogurt"]):
            b = tk.Button(pop, text=food.capitalize(), bg=CARD2, fg=TEXT2,
                         font=("Segoe UI",9), bd=0, cursor="hand2", padx=10, pady=6,
                         command=lambda f=food: self.quick_scan(f), relief="flat",
                         highlightthickness=1, highlightbackground=BORDER)
            b.grid(row=i//3, column=i%3, padx=3, pady=3, sticky="ew")
        for i in range(3):
            pop.columnconfigure(i, weight=1)

        self.current_scan_data = None

    def do_scan(self):
        query = self.scan_entry.get().lower().strip()
        self.quick_scan(query)

    def quick_scan(self, query):
        match = None
        for key, data in FOODS.items():
            if key in query or query in key:
                match = data
                break
        if not match:
            match = random.choice(list(FOODS.values()))

        self.scan_title.config(text=match["name"], fg=TEXT)
        self.scan_conf.config(text=f"✦ {random.randint(88,99)}% confidence match · 100g serving")
        self.nutr_labels["kcal"].config(text=str(match["kcal"]))
        self.nutr_labels["protein"].config(text=match["protein"])
        self.nutr_labels["fat"].config(text=match["fat"])
        self.nutr_labels["carbs"].config(text=match["carbs"])
        self.current_scan_data = match
        self.set_status(f"✅ Detected: {match['name']}")

    def add_scanned_meal(self):
        if not self.current_scan_data:
            messagebox.showinfo("Scan First", "Please scan a food first!")
            return
        d = self.current_scan_data
        self.meals.append({"emoji":"🍽️","name":d["name"],"time":"Just now · Scanned","kcal":d["kcal"]})
        self.render_meals()
        self.set_status(f"✅ Added: {d['name']} ({d['kcal']} kcal)")
        messagebox.showinfo("Added!", f"{d['name']} added to your meal log!")

    # ══════════════════════════════════════
    # SCREEN: WORKOUT TRACKER
    # ══════════════════════════════════════
    def build_workout(self):
        frame = tk.Frame(self.content, bg=BG)
        self.screens["workout"] = frame

        # Header
        hdr = self.card(frame)
        hdr.pack(fill="x", padx=12, pady=(12,6))
        tk.Label(hdr, text="💪 Upper Body Push Day", bg=CARD, fg=LIME,
                font=("Segoe UI",13,"bold")).pack(anchor="w", padx=14, pady=(10,2))
        live = tk.Frame(hdr, bg=CARD)
        live.pack(anchor="w", padx=14, pady=(0,10))
        tk.Label(live, text="● LIVE SESSION", bg=CARD, fg=RED,
                font=("Segoe UI",9,"bold")).pack(side="left")

        # Timer + stats
        stats = tk.Frame(frame, bg=BG)
        stats.pack(fill="x", padx=12, pady=6)

        timer_box = self.card(stats)
        timer_box.pack(side="left", fill="both", expand=True, padx=(0,4))
        self.label(timer_box, "⏱ ELAPSED", 8, MUTED).pack(pady=(8,0))
        self.timer_lbl = tk.Label(timer_box, text="24:18", bg=CARD, fg=LIME,
                                   font=("Segoe UI",24,"bold"))
        self.timer_lbl.pack(pady=(0,8))

        right_stats = tk.Frame(stats, bg=BG)
        right_stats.pack(side="left", fill="both", expand=True)
        for label, val, color in [("🔥 KCAL","312",LIME),("❤️ BPM","148",RED)]:
            b = self.card(right_stats)
            b.pack(fill="x", pady=2)
            tk.Label(b, text=label, bg=CARD, fg=MUTED, font=("Segoe UI",8)).pack(side="left", padx=10, pady=8)
            tk.Label(b, text=val, bg=CARD, fg=color, font=("Segoe UI",13,"bold")).pack(side="right", padx=10)

        # Exercise list
        self.label(frame, "Exercises", 11, TEXT, True).pack(anchor="w", padx=16, pady=(10,4))

        self.ex_frame = tk.Frame(frame, bg=BG)
        self.ex_frame.pack(fill="x", padx=12)

        self.exercises_data = [
            {"name":"Bench Press",    "sets":"4 sets · 60kg",         "done":True},
            {"name":"Overhead Press", "sets":"3 sets · 40kg",         "done":True},
            {"name":"Push-Ups",       "sets":"3 sets · Bodyweight",   "done":True},
            {"name":"Dumbbell Flyes", "sets":"3 sets · 15kg",         "done":True},
            {"name":"Tricep Dips",    "sets":"3 sets · Bodyweight",   "done":False, "current":True},
            {"name":"Lateral Raises", "sets":"3 sets · 10kg",         "done":False},
        ]
        self.render_exercises()

        # Controls
        ctrl = tk.Frame(frame, bg=BG)
        ctrl.pack(fill="x", padx=12, pady=12)
        self.btn(ctrl, "⏸ Pause", lambda: self.set_status("Workout paused"),
                 bg=CARD2, fg=TEXT).pack(side="left", padx=(0,8))
        self.btn(ctrl, "Next Exercise →", self.next_exercise).pack(side="left", fill="x", expand=True)
        self.btn(ctrl, "🏗 Build Routine", self.open_builder, bg=CARD2, fg=TEAL).pack(side="right")

    def render_exercises(self):
        for w in self.ex_frame.winfo_children():
            w.destroy()
        done_count = sum(1 for e in self.exercises_data if e["done"])
        for i, ex in enumerate(self.exercises_data):
            row = tk.Frame(self.ex_frame, bg=CARD if ex.get("current") else CARD,
                          highlightthickness=1,
                          highlightbackground=LIME if ex.get("current") else BORDER)
            row.pack(fill="x", pady=2)
            num_color = LIME if ex["done"] else (LIME if ex.get("current") else MUTED)
            num_text = "✓" if ex["done"] else str(i+1)
            tk.Label(row, text=num_text, bg=CARD, fg=num_color,
                    font=("Segoe UI",10,"bold"), width=3).pack(side="left", padx=8, pady=8)
            info = tk.Frame(row, bg=CARD)
            info.pack(side="left", fill="both", expand=True, pady=8)
            status = "Done" if ex["done"] else ("In Progress" if ex.get("current") else "Up next")
            tk.Label(info, text=ex["name"], bg=CARD, fg=TEXT,
                    font=("Segoe UI",10,"bold"), anchor="w").pack(anchor="w")
            tk.Label(info, text=f"{ex['sets']} · {status}", bg=CARD, fg=MUTED,
                    font=("Segoe UI",8), anchor="w").pack(anchor="w")

    def next_exercise(self):
        for i, ex in enumerate(self.exercises_data):
            if ex.get("current"):
                ex["done"] = True
                ex.pop("current", None)
                if i + 1 < len(self.exercises_data):
                    self.exercises_data[i+1]["current"] = True
                    self.set_status(f"Next: {self.exercises_data[i+1]['name']}")
                else:
                    self.set_status("🏆 Workout Complete!")
                    messagebox.showinfo("Workout Complete!", "Amazing work! You finished all exercises! 🏆")
                self.render_exercises()
                return
        self.set_status("No active exercise")

    def start_timer(self):
        self.timer_running = True
        self.update_timer()

    def update_timer(self):
        if self.timer_running and self.current_screen == "workout":
            self.timer_sec += 1
            m = self.timer_sec // 60
            s = self.timer_sec % 60
            self.timer_lbl.config(text=f"{m:02d}:{s:02d}")
        self.root.after(1000, self.update_timer)

    def open_builder(self):
        win = tk.Toplevel(self.root)
        win.title("🏗 Build Custom Routine")
        win.geometry("420x500")
        win.configure(bg=BG)
        win.grab_set()

        tk.Label(win, text="🔥 Build Custom Routine", bg=BG, fg=LIME,
                font=("Segoe UI",13,"bold")).pack(pady=(16,4))
        tk.Label(win, text="Add exercises to your routine", bg=BG, fg=MUTED,
                font=("Segoe UI",9)).pack()

        list_frame = tk.Frame(win, bg=BG)
        list_frame.pack(fill="both", expand=True, padx=16, pady=10)

        tree = ttk.Treeview(list_frame, columns=("Exercise","Sets"), show="headings", height=8)
        tree.heading("Exercise", text="Exercise")
        tree.heading("Sets", text="Sets")
        tree.column("Exercise", width=200)
        tree.column("Sets", width=100)

        routine = [("Bench Press","4x8-10"),("Overhead Press","3x8"),("Tricep Dips","3x12")]
        for ex, sets in routine:
            tree.insert("", "end", values=(ex, sets))

        tree.pack(fill="both", expand=True)

        btn_row = tk.Frame(win, bg=BG)
        btn_row.pack(fill="x", padx=16, pady=8)

        def add_ex():
            for ex_data in EXERCISES:
                if ex_data[0] not in [tree.item(i)["values"][0] for i in tree.get_children()]:
                    tree.insert("", "end", values=(ex_data[0], ex_data[3]))
                    self.set_status(f"Added: {ex_data[0]}")
                    break

        def remove_ex():
            sel = tree.selection()
            if sel:
                tree.delete(sel[0])

        tk.Button(btn_row, text="+ Add Exercise", bg=CARD2, fg=LIME,
                 font=("Segoe UI",9,"bold"), bd=0, cursor="hand2",
                 command=add_ex, padx=10, pady=6).pack(side="left", padx=(0,6))
        tk.Button(btn_row, text="✕ Remove", bg=CARD2, fg=RED,
                 font=("Segoe UI",9,"bold"), bd=0, cursor="hand2",
                 command=remove_ex, padx=10, pady=6).pack(side="left")
        tk.Button(btn_row, text="💾 Save Routine", bg=LIME, fg=BG,
                 font=("Segoe UI",10,"bold"), bd=0, cursor="hand2",
                 command=lambda: [self.set_status("✅ Routine saved!"), win.destroy()],
                 padx=10, pady=8).pack(side="right")

    # ══════════════════════════════════════
    # SCREEN: EXERCISE LIBRARY
    # ══════════════════════════════════════
    def build_library(self):
        frame = tk.Frame(self.content, bg=BG)
        self.screens["library"] = frame

        self.label(frame, "📚 Exercise Library", 14, LIME, True).pack(pady=(16,4))

        # Search + filter
        search_row = tk.Frame(frame, bg=BG)
        search_row.pack(fill="x", padx=16, pady=8)

        self.lib_search = tk.Entry(search_row, bg=CARD2, fg=TEXT, font=("Segoe UI",10),
                                   insertbackground=LIME, relief="flat", bd=0,
                                   highlightthickness=1, highlightbackground=BORDER)
        self.lib_search.insert(0, "Search exercises...")
        self.lib_search.bind("<FocusIn>", lambda e: self.lib_search.delete(0,"end") if "Search" in self.lib_search.get() else None)
        self.lib_search.pack(side="left", fill="x", expand=True, ipady=6, padx=(0,8))
        self.btn(search_row, "🔍", self.filter_exercises, bg=CARD2, fg=LIME).pack(side="right")

        filter_row = tk.Frame(frame, bg=BG)
        filter_row.pack(fill="x", padx=16, pady=(0,8))
        self.muscle_var = tk.StringVar(value="All")
        for muscle in ["All","Chest","Back","Legs","Arms","Core","Shoulders"]:
            rb = tk.Radiobutton(filter_row, text=muscle, variable=self.muscle_var,
                               value=muscle, bg=BG, fg=MUTED,
                               selectcolor=CARD2, activebackground=BG,
                               font=("Segoe UI",8), cursor="hand2",
                               command=self.filter_exercises,
                               indicatoron=False, padx=6, pady=3,
                               relief="flat", bd=0,
                               highlightthickness=1, highlightbackground=BORDER)
            rb.pack(side="left", padx=2)

        # Exercise table
        cols = ("Exercise", "Muscle", "Level", "Sets")
        self.lib_tree = ttk.Treeview(frame, columns=cols, show="headings", height=14)
        for col in cols:
            self.lib_tree.heading(col, text=col)
        self.lib_tree.column("Exercise", width=160)
        self.lib_tree.column("Muscle",   width=80)
        self.lib_tree.column("Level",    width=90)
        self.lib_tree.column("Sets",     width=80)
        self.lib_tree.pack(fill="both", expand=True, padx=16, pady=4)
        self.lib_tree.bind("<Double-1>", self.on_exercise_click)

        self.filter_exercises()

        self.label(frame, "Double-click any exercise to add to workout", 8, MUTED).pack(pady=4)

    def filter_exercises(self):
        search = self.lib_search.get().lower()
        muscle = self.muscle_var.get()
        for row in self.lib_tree.get_children():
            self.lib_tree.delete(row)
        for ex in EXERCISES:
            name, mus, level, sets = ex
            if (muscle == "All" or mus == muscle) and \
               ("search" not in search and (search in name.lower() or search in mus.lower() or not search or search == "search exercises...")):
                self.lib_tree.insert("", "end", values=ex)

    def on_exercise_click(self, event):
        sel = self.lib_tree.selection()
        if sel:
            name = self.lib_tree.item(sel[0])["values"][0]
            self.set_status(f"▶ Playing demo: {name}")
            messagebox.showinfo("Video Demo", f"Playing demo for: {name}\n\n(In a real app this would open a video tutorial)")

    # ══════════════════════════════════════
    # SCREEN: AI COACH
    # ══════════════════════════════════════
    def build_coach(self):
        frame = tk.Frame(self.content, bg=BG)
        self.screens["coach"] = frame

        self.label(frame, "🧠 AI Nutrition Coach", 14, LIME, True).pack(pady=(12,2))
        self.label(frame, "Powered by Claude AI", 9, MUTED).pack()

        # Chat area
        chat_outer = tk.Frame(frame, bg=CARD, highlightthickness=1,
                              highlightbackground=BORDER)
        chat_outer.pack(fill="both", expand=True, padx=12, pady=8)

        self.chat_display = scrolledtext.ScrolledText(
            chat_outer, bg=CARD, fg=TEXT, font=("Segoe UI",10),
            wrap=tk.WORD, bd=0, padx=10, pady=10,
            insertbackground=LIME, state="disabled",
            selectbackground=LIME, selectforeground=BG
        )
        self.chat_display.pack(fill="both", expand=True)

        # Tags for colored messages
        self.chat_display.tag_configure("ai_name", foreground=LIME, font=("Segoe UI",9,"bold"))
        self.chat_display.tag_configure("ai_msg",  foreground=TEXT2, font=("Segoe UI",10))
        self.chat_display.tag_configure("user_msg",foreground=LIME,  font=("Segoe UI",10,"bold"))
        self.chat_display.tag_configure("user_lbl",foreground=TEAL,  font=("Segoe UI",9,"bold"))
        self.chat_display.tag_configure("error",   foreground=RED,   font=("Segoe UI",9))
        self.chat_display.tag_configure("divider", foreground=BORDER)

        # Quick questions
        quick = tk.Frame(frame, bg=BG)
        quick.pack(fill="x", padx=12, pady=(0,6))
        qs = ["Today's nutrition?", "Post-workout meal?", "Rest day advice?", "Protein intake?"]
        for q in qs:
            tk.Button(quick, text=q, bg=CARD2, fg=LIME,
                     font=("Segoe UI",8), bd=0, cursor="hand2",
                     command=lambda t=q: self.send_message(t),
                     padx=8, pady=4, relief="flat",
                     highlightthickness=1, highlightbackground=BORDER).pack(side="left", padx=2)

        # Input area
        input_row = tk.Frame(frame, bg=BG)
        input_row.pack(fill="x", padx=12, pady=(0,8))

        self.chat_input = tk.Entry(input_row, bg=CARD2, fg=TEXT, font=("Segoe UI",11),
                                   insertbackground=LIME, relief="flat", bd=0,
                                   highlightthickness=1, highlightbackground=BORDER)
        self.chat_input.pack(side="left", fill="x", expand=True, ipady=8, padx=(0,8))
        self.chat_input.bind("<Return>", lambda e: self.send_message())
        self.chat_input.insert(0, "Ask about nutrition, workouts, recovery...")
        self.chat_input.bind("<FocusIn>", lambda e: self.chat_input.delete(0,"end") if "Ask about" in self.chat_input.get() else None)

        self.send_btn = self.btn(input_row, "Send ↑", self.send_message)
        self.send_btn.pack(side="right")

        # Welcome message
        self.append_chat("Vitality AI", "👋 Hi Alex! I'm your Vitality AI coach, powered by Claude. Ask me anything about nutrition, workouts, or recovery!", "ai")

    def append_chat(self, sender, message, msg_type):
        self.chat_display.config(state="normal")
        if msg_type == "ai":
            self.chat_display.insert("end", f"\n{sender}\n", "ai_name")
            self.chat_display.insert("end", f"{message}\n", "ai_msg")
        elif msg_type == "user":
            self.chat_display.insert("end", f"\nYou\n", "user_lbl")
            self.chat_display.insert("end", f"{message}\n", "user_msg")
        elif msg_type == "error":
            self.chat_display.insert("end", f"\n{message}\n", "error")
        self.chat_display.insert("end", "─" * 50 + "\n", "divider")
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")

    def send_message(self, text=None):
        msg = text or self.chat_input.get().strip()
        if not msg or "Ask about" in msg:
            return
        self.chat_input.delete(0, "end")
        self.append_chat("You", msg, "user")
        self.chat_history.append({"role": "user", "content": msg})
        self.send_btn.config(state="disabled", text="...")
        self.set_status("🧠 AI is thinking...")

        thread = threading.Thread(target=self.call_claude, args=(msg,), daemon=True)
        thread.start()

    def call_claude(self, msg):
        total_kcal = sum(m["kcal"] for m in self.meals)
        meal_names = ", ".join(m["name"] for m in self.meals)
        system = (f"You are Vitality AI, a friendly fitness and nutrition coach. "
                  f"User is Alex. Today's meals: {meal_names} ({total_kcal} kcal, goal 1800). "
                  f"Be concise (2-4 sentences), warm, actionable. Use **bold** for key terms.")

        messages = self.chat_history[-8:]

        try:
            if API_KEY == "PASTE_YOUR_KEY_HERE":
                raise ValueError("No API key set")

            resp = requests.post(
                API_URL,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01"
                },
                json={"model": MODEL, "max_tokens": 1000,
                      "system": system, "messages": messages},
                timeout=15
            )
            reply = resp.json()["content"][0]["text"]
        except ValueError:
            replies = [
                f"You're at **{sum(m['kcal'] for m in self.meals)} kcal** today — great progress! Focus on hitting your protein target for optimal muscle recovery.",
                "Post-workout, aim for a **3:1 carb-to-protein ratio** within 30 minutes. Greek yogurt with banana is perfect!",
                "Aim for **1-2 rest days per week** depending on intensity. Your Thursday rest day looks ideal for recovery!",
                "Your **protein intake** looks strong today! Consider adding leafy greens to boost your micronutrient profile."
            ]
            reply = random.choice(replies)
        except Exception as e:
            reply = f"Connection error: {str(e)[:60]}. Please check your API key."

        self.chat_history.append({"role": "assistant", "content": reply})
        self.root.after(0, lambda: self.on_reply(reply))

    def on_reply(self, reply):
        self.append_chat("Vitality AI", reply, "ai")
        self.send_btn.config(state="normal", text="Send ↑")
        self.set_status("✅ Ready")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    print("Starting Vitality AI Desktop App...")
    app = VitalityAI()
    app.run()
