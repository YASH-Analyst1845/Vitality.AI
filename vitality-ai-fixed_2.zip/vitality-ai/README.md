# ⚡ Vitality AI - Python Flask App

## Setup & Run

### 1. Install dependencies
```
pip install -r requirements.txt
```

### 2. Run the app
```
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

## Features
- AI Food Scanner (simulated camera detection)
- Manual food entry
- Live Workout Tracker with timer
- Exercise Library with filters
- Custom Routine Builder
- Rest Day Scheduler with calendar
- AI Nutrition Coach (Claude AI powered)
- Nutrition Insights with macro breakdown

## API Endpoints
- GET  /              → Main app
- POST /api/coach     → AI chat (Claude)
- POST /api/scan      → Food scan lookup
- GET  /api/exercises → Exercise library

## Note
The AI Coach uses the Claude API via the frontend.
No API key needed for the demo mode (fallback responses built in).
