from flask import Flask, render_template_string, request, jsonify, Response
import requests
import json

app = Flask(__name__)

CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL = "claude-sonnet-4-20250514"
API_KEY = "sk-ant-api03-ENTYZq5toeUkeqF2uqHBXNMu7n9JGLvLQ8a5waGzisUWDDspSCCesBfxD1XS_GGpmZEmXmQsvUFg84Dmm8UxvQ-nMwcdgAA"

# ── Sample food database ──
FOOD_DB = {
    "chicken": {"name": "Grilled Chicken Breast", "kcal": 165, "protein": "31g", "fat": "3.6g", "carbs": "0g", "confidence": "97%"},
    "rice":    {"name": "Brown Rice (cooked)",    "kcal": 216, "protein": "5g",   "fat": "1.8g", "carbs": "45g","confidence": "92%"},
    "egg":     {"name": "Scrambled Eggs (2)",     "kcal": 182, "protein": "12g",  "fat": "14g",  "carbs": "2g", "confidence": "95%"},
    "banana":  {"name": "Banana (Medium)",        "kcal": 89,  "protein": "1.1g", "fat": "0.3g", "carbs": "23g","confidence": "99%"},
    "salad":   {"name": "Caesar Salad",           "kcal": 220, "protein": "8g",   "fat": "14g",  "carbs": "18g","confidence": "91%"},
    "yogurt":  {"name": "Greek Yogurt (plain)",   "kcal": 130, "protein": "17g",  "fat": "4g",   "carbs": "9g", "confidence": "93%"},
    "oats":    {"name": "Overnight Oats",         "kcal": 380, "protein": "14g",  "fat": "8g",   "carbs": "62g","confidence": "94%"},
    "apple":   {"name": "Apple (Medium)",         "kcal": 95,  "protein": "0.5g", "fat": "0.3g", "carbs": "25g","confidence": "98%"},
}

EXERCISES = [
    {"name": "Barbell Bench Press", "muscle": "Chest",     "level": "Intermediate", "sets": "4x8-12", "dur": "2:34"},
    {"name": "Push-Up Variations",  "muscle": "Full Body", "level": "Beginner",     "sets": "3x15-20","dur": "1:48"},
    {"name": "Overhead Press",      "muscle": "Shoulders", "level": "Intermediate", "sets": "4x8-10", "dur": "3:10"},
    {"name": "Tricep Pushdown",     "muscle": "Arms",      "level": "Beginner",     "sets": "3x12-15","dur": "1:55"},
    {"name": "Pull-Ups",            "muscle": "Back",      "level": "Intermediate", "sets": "4x6-10", "dur": "2:20"},
    {"name": "Barbell Squat",       "muscle": "Legs",      "level": "Beginner",     "sets": "4x8-12", "dur": "3:00"},
    {"name": "Deadlift",            "muscle": "Back",      "level": "Advanced",     "sets": "3x5",    "dur": "3:45"},
    {"name": "Cable Flyes",         "muscle": "Chest",     "level": "Beginner",     "sets": "3x15",   "dur": "1:30"},
    {"name": "Bicep Curls",         "muscle": "Arms",      "level": "Beginner",     "sets": "3x12",   "dur": "1:40"},
    {"name": "Plank Hold",          "muscle": "Core",      "level": "Beginner",     "sets": "3x60s",  "dur": "1:15"},
    {"name": "Leg Press",           "muscle": "Legs",      "level": "Beginner",     "sets": "4x10-12","dur": "2:10"},
    {"name": "Lateral Raises",      "muscle": "Shoulders", "level": "Beginner",     "sets": "3x15",   "dur": "1:50"},
]

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>Vitality AI</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --lime:#C8F135;--dark:#0D0F0A;--dark2:#141710;
  --card:#1A1E14;--card2:#222818;
  --border:rgba(200,241,53,0.13);
  --muted:#6B7355;--text:#E8EDDA;--text2:#A8B090;
  --red:#FF5C5C;--orange:#FF9B42;--teal:#3CFFD0;
}
html,body{height:100%;background:#0D0F0A;overflow:hidden;position:fixed;inset:0;}
body{font-family:'Segoe UI',sans-serif;color:var(--text);}
.screen{position:absolute;inset:0;display:none;flex-direction:column;background:var(--dark2);}
.screen.active{display:flex;animation:si .22s ease forwards;}
@keyframes si{from{opacity:0;transform:translateX(20px);}to{opacity:1;transform:translateX(0);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}
@keyframes scan{0%,100%{top:6px}50%{top:calc(100% - 6px)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes ldot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.3;transform:scale(.6)}}
.sbar{display:flex;justify-content:space-between;padding:max(14px,env(safe-area-inset-top,14px)) 20px 6px;font-size:12px;color:var(--text2);flex-shrink:0;}
.sbar .t{font-weight:700;font-size:14px;color:var(--text);}
.bnav{position:absolute;bottom:0;left:0;right:0;height:calc(62px + env(safe-area-inset-bottom,0px));
  background:rgba(13,15,10,.97);border-top:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-around;
  padding:0 4px calc(6px + env(safe-area-inset-bottom,0px));z-index:100;}
.ni{display:flex;flex-direction:column;align-items:center;gap:3px;font-size:9px;letter-spacing:.8px;text-transform:uppercase;color:var(--muted);font-weight:600;cursor:pointer;padding:5px 10px;border-radius:10px;-webkit-tap-highlight-color:transparent;}
.ni.active{color:var(--lime);}
.ni-i{font-size:21px;line-height:1;}
.sbody{flex:1;overflow-y:auto;overflow-x:hidden;padding-bottom:calc(70px + env(safe-area-inset-bottom,0px));-webkit-overflow-scrolling:touch;}
.sbody::-webkit-scrollbar{display:none;}
.ph{padding:0 18px;}
.sec-h{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;}
.sec-h h3{font-size:14px;font-weight:700;}
.sec-h span{font-size:11px;color:var(--lime);cursor:pointer;}
.pill{display:inline-flex;align-items:center;padding:4px 10px;border-radius:20px;font-size:10px;font-weight:700;}
.pl{background:rgba(200,241,53,.12);color:var(--lime);}
.pt{background:rgba(60,255,208,.12);color:var(--teal);}
.po{background:rgba(255,155,66,.12);color:var(--orange);}
.pr{background:rgba(255,92,92,.12);color:var(--red);}
.btn-lime{width:100%;background:var(--lime);border:none;border-radius:14px;padding:15px;font-size:15px;font-weight:800;color:#0D0F0A;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:opacity .15s,transform .1s;}
.btn-lime:active{opacity:.82;transform:scale(.97);}
.card{background:var(--card);border:1px solid rgba(255,255,255,.04);border-radius:16px;padding:14px;}
.card2{background:var(--card2);border:1px solid var(--border);border-radius:16px;padding:14px;}
.tbar{padding:8px 18px 14px;display:flex;align-items:center;gap:12px;border-bottom:1px solid var(--border);flex-shrink:0;}
.tbar h2{font-size:19px;font-weight:800;flex:1;}
.back{font-size:22px;color:var(--lime);cursor:pointer;padding:4px 6px 4px 0;-webkit-tap-highlight-color:transparent;}
.toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(16px);background:rgba(34,40,24,.97);border:1px solid var(--border);border-radius:12px;padding:10px 20px;font-size:12px;font-weight:600;color:var(--text);opacity:0;transition:opacity .3s,transform .3s;z-index:9999;white-space:nowrap;pointer-events:none;box-shadow:0 8px 32px rgba(0,0,0,.5);}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}

/* ONBOARD */
#s-ob{background:#0D0F0A;justify-content:flex-start;overflow-y:auto;}
#s-ob::before{content:'';position:fixed;inset:0;pointer-events:none;background:radial-gradient(ellipse 60% 40% at 50% 20%,rgba(200,241,53,.1) 0%,transparent 70%);}
.ob-in{position:relative;z-index:2;padding:clamp(40px,10vh,80px) 24px 40px;min-height:100%;display:flex;flex-direction:column;}
.ob-ic{font-size:clamp(52px,14vw,72px);margin-bottom:16px;animation:fadeUp .5s ease both;}
.ob-nm{font-size:clamp(36px,10vw,52px);font-weight:800;color:var(--lime);letter-spacing:-1px;animation:fadeUp .5s .1s ease both;opacity:0;}
.ob-tg{font-size:12px;color:var(--muted);margin-top:4px;letter-spacing:2.5px;text-transform:uppercase;animation:fadeUp .5s .15s ease both;opacity:0;}
.ob-fs{margin:clamp(24px,5vh,40px) 0;display:flex;flex-direction:column;gap:12px;animation:fadeUp .5s .2s ease both;opacity:0;}
.feat{display:flex;align-items:center;gap:14px;padding:14px 16px;background:rgba(255,255,255,.04);border-radius:14px;border:1px solid var(--border);}
.feat-i{font-size:26px;flex-shrink:0;width:36px;text-align:center;}
.feat-t{font-size:13px;font-weight:600;}
.feat-s{font-size:11px;color:var(--muted);margin-top:2px;}
.ob-bw{animation:fadeUp .5s .28s ease both;opacity:0;margin-top:auto;}

/* HOME */
#s-home::before{content:'';position:absolute;top:0;left:0;right:0;height:50%;pointer-events:none;background:radial-gradient(ellipse 70% 50% at 90% 0%,rgba(200,241,53,.07) 0%,transparent 70%);}
.gr-row{padding:8px 18px 16px;display:flex;justify-content:space-between;align-items:flex-start;position:relative;z-index:1;}
.gr-nm{font-size:clamp(20px,5.5vw,26px);font-weight:800;line-height:1.1;}
.gr-sb{font-size:11px;color:var(--muted);margin-top:3px;}
.av{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,var(--lime),var(--teal));display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#0D0F0A;box-shadow:0 0 20px rgba(200,241,53,.25);}
.rc{margin:0 18px 16px;background:var(--card2);border-radius:20px;border:1px solid var(--border);padding:16px;display:flex;align-items:center;gap:16px;}
.rs-big{font-size:clamp(26px,7vw,34px);font-weight:800;color:var(--lime);line-height:1;}
.rs-lb{font-size:10px;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;margin-top:2px;}
.mr{display:flex;gap:8px;margin-top:12px;}
.mcr{flex:1;background:rgba(255,255,255,.04);border-radius:10px;padding:8px 4px;text-align:center;}
.mcr-v{font-size:14px;font-weight:700;}
.mcr-u{font-size:9px;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;}
.qa{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:0 18px;margin-bottom:16px;}
.qac{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:14px 12px;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .12s;}
.qac:active{transform:scale(.96);}
.qa-i{font-size:28px;margin-bottom:8px;}
.qa-l{font-size:13px;font-weight:700;}
.qa-s{font-size:10px;color:var(--muted);margin-top:2px;}
.mi{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:14px;padding:12px 14px;border:1px solid rgba(255,255,255,.04);margin-bottom:8px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.mi:active{opacity:.8;}
.me{font-size:26px;width:34px;text-align:center;flex-shrink:0;}
.mn{font-size:13px;font-weight:600;}
.mt{font-size:10px;color:var(--muted);}
.mk{font-size:14px;font-weight:700;color:var(--lime);margin-left:auto;flex-shrink:0;}
.wc{margin:0 18px 16px;background:var(--card2);border-radius:16px;border:1px solid var(--border);padding:14px;}
.wh{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;}
.wh span:first-child{font-size:12px;font-weight:600;}
.wtr{height:8px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden;}
.wf{height:100%;border-radius:4px;background:linear-gradient(90deg,#5b9fff,#3a7fdd);width:60%;}

/* SCAN */
#s-sc{background:#000;}
.cam{position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 48px,rgba(200,241,53,.02) 48px,rgba(200,241,53,.02) 49px),repeating-linear-gradient(90deg,transparent,transparent 48px,rgba(200,241,53,.02) 48px,rgba(200,241,53,.02) 49px),radial-gradient(ellipse at 50% 35%,rgba(20,30,12,1) 0%,#000 65%);}
.sh{position:absolute;top:0;left:0;right:0;padding:max(40px,env(safe-area-inset-top,40px)) 20px 16px;display:flex;align-items:center;gap:12px;background:linear-gradient(180deg,rgba(0,0,0,.85) 0%,transparent 100%);z-index:10;}
.bk{width:40px;height:40px;background:rgba(255,255,255,.12);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.sf{position:absolute;top:18%;left:50%;transform:translateX(-50%);width:min(240px,65vw);height:min(240px,65vw);}
.sfc{position:absolute;width:30px;height:30px;}
.sfc.tl{top:0;left:0;border-top:3px solid var(--lime);border-left:3px solid var(--lime);border-radius:5px 0 0 0;}
.sfc.tr{top:0;right:0;border-top:3px solid var(--lime);border-right:3px solid var(--lime);border-radius:0 5px 0 0;}
.sfc.bl{bottom:0;left:0;border-bottom:3px solid var(--lime);border-left:3px solid var(--lime);border-radius:0 0 0 5px;}
.sfc.br{bottom:0;right:0;border-bottom:3px solid var(--lime);border-right:3px solid var(--lime);border-radius:0 0 5px 0;}
.sb{position:absolute;left:8px;right:8px;height:2px;background:linear-gradient(90deg,transparent,var(--lime),transparent);box-shadow:0 0 12px var(--lime);animation:scan 2s ease-in-out infinite;}
.dl{position:absolute;top:calc(18% + min(240px,65vw) + 18px);left:50%;transform:translateX(-50%);background:var(--lime);color:#0D0F0A;font-weight:800;font-size:13px;padding:7px 22px;border-radius:20px;white-space:nowrap;box-shadow:0 0 22px rgba(200,241,53,.4);animation:pulse 1.5s ease infinite;display:none;}
.dl.show{display:block;}
.sct{position:absolute;bottom:33%;left:0;right:0;display:flex;justify-content:center;gap:24px;align-items:center;}
.ci{width:52px;height:52px;background:rgba(255,255,255,.12);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;cursor:pointer;backdrop-filter:blur(10px);-webkit-tap-highlight-color:transparent;}
.shu{width:72px;height:72px;background:var(--lime);border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 0 28px rgba(200,241,53,.5);font-size:28px;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .1s;}
.shu:active{transform:scale(.9);}
.rs{position:absolute;bottom:0;left:0;right:0;background:var(--dark2);border-radius:26px 26px 0 0;border-top:1px solid var(--border);padding:20px 20px calc(20px + env(safe-area-inset-bottom,0px));transform:translateY(100%);transition:transform .38s cubic-bezier(.34,1.4,.64,1);}
.rs.open{transform:translateY(0);}
.dp{width:40px;height:4px;background:var(--muted);border-radius:2px;margin:0 auto 18px;opacity:.35;}
.ft{font-size:22px;font-weight:800;margin-bottom:4px;}
.cf{font-size:12px;color:var(--teal);margin-bottom:16px;}
.ng{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px;}
.nb{background:var(--card2);border-radius:12px;padding:12px 6px;text-align:center;border:1px solid var(--border);}
.nv{font-size:17px;font-weight:800;line-height:1;}
.nl{font-size:9px;color:var(--muted);margin-top:3px;text-transform:uppercase;letter-spacing:.8px;}

/* MANUAL ENTRY */
.inp-row{display:flex;flex-direction:column;gap:8px;margin-bottom:14px;}
.inp-row label{font-size:11px;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;}
.inp{background:var(--card2);border:1px solid var(--border);border-radius:12px;padding:12px 14px;color:var(--text);font-size:14px;outline:none;width:100%;}
.inp:focus{border-color:rgba(200,241,53,.3);}
.inp-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;}

/* NUTRITION */
.aic{background:linear-gradient(135deg,rgba(200,241,53,.07),rgba(60,255,208,.04));border:1px solid rgba(200,241,53,.16);border-radius:18px;padding:16px;margin:0 18px 16px;}
.aih{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
.aiav{width:30px;height:30px;background:var(--lime);border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:13px;color:#0D0F0A;font-weight:800;}
.ainm{font-size:11px;font-weight:700;color:var(--lime);letter-spacing:1px;text-transform:uppercase;}
.aic p{font-size:12px;color:var(--text2);line-height:1.75;}
.aic p b{color:var(--lime);}
.ald{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);}
.asp{width:14px;height:14px;border:2px solid rgba(200,241,53,.2);border-top-color:var(--lime);border-radius:50%;animation:spin .8s linear infinite;}
.br-row{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
.bl{font-size:11px;color:var(--muted);width:52px;font-weight:500;}
.btr{flex:1;height:8px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden;}
.bf{height:100%;border-radius:4px;}
.bv{font-size:11px;font-weight:700;width:36px;text-align:right;}
.scr{display:flex;gap:10px;margin:0 18px 16px;}
.scc{flex:1;background:var(--card2);border:1px solid var(--border);border-radius:14px;padding:14px;text-align:center;}
.scn{font-size:28px;font-weight:800;line-height:1;}
.scl{font-size:9px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-top:3px;}
.mch{display:flex;flex-wrap:wrap;gap:7px;padding:0 18px 16px;}
.mc{padding:6px 12px;border-radius:20px;font-size:10px;font-weight:600;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);}
.mcg{border-color:rgba(200,241,53,.2);color:var(--lime);}
.mcw{border-color:rgba(255,155,66,.2);color:var(--orange);}

/* WORKOUT */
.wkh{padding:8px 18px 12px;}
.wkh h2{font-size:clamp(20px,5.5vw,26px);font-weight:800;}
.wkd{font-size:11px;color:var(--muted);margin-top:3px;}
.lb{display:inline-flex;align-items:center;gap:6px;margin-top:10px;background:rgba(255,92,92,.1);border:1px solid rgba(255,92,92,.22);border-radius:20px;padding:5px 12px;font-size:10px;font-weight:700;color:var(--red);letter-spacing:1px;text-transform:uppercase;}
.ld{width:6px;height:6px;background:var(--red);border-radius:50%;flex-shrink:0;animation:ldot 1s ease infinite;}
.tw{display:flex;justify-content:center;padding:10px 0;position:relative;}
.tc{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;}
.tb{font-size:clamp(24px,7vw,32px);font-weight:800;color:var(--lime);line-height:1;}
.ts{font-size:9px;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase;}
.str{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:0 18px;margin-bottom:14px;}
.sb2{background:var(--card2);border-radius:14px;padding:12px 8px;text-align:center;border:1px solid var(--border);}
.sv{font-size:clamp(16px,4.5vw,22px);font-weight:800;line-height:1;}
.sl{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}
.exi{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:14px;padding:13px;border:1px solid rgba(255,255,255,.04);margin-bottom:8px;}
.exi.curr{border-color:rgba(200,241,53,.2);background:rgba(200,241,53,.03);}
.exn{width:30px;height:30px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;}
.ed{background:var(--lime);color:#0D0F0A;}
.ec{background:rgba(200,241,53,.12);color:var(--lime);border:1.5px solid var(--lime);}
.en{background:rgba(255,255,255,.06);color:var(--muted);}
.exnm{font-size:13px;font-weight:600;}
.exst{font-size:10px;color:var(--muted);margin-top:2px;}
.exi-i{font-size:20px;margin-left:auto;flex-shrink:0;}
.cr{display:flex;gap:10px;padding:0 18px;margin-bottom:8px;}
.cp{flex:1;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:12px;padding:14px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.cn{flex:2;background:var(--lime);color:#0D0F0A;border:none;border-radius:12px;padding:14px;font-size:14px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;-webkit-tap-highlight-color:transparent;transition:opacity .15s;}
.cn:active{opacity:.82;}

/* LIBRARY */
.lh{padding:8px 18px 0;flex-shrink:0;}
.lh h2{font-size:clamp(20px,5.5vw,24px);font-weight:800;}
.si2{display:flex;align-items:center;background:var(--card2);border-radius:12px;padding:0 14px;border:1px solid var(--border);gap:8px;margin-top:10px;}
.si2 input{background:none;border:none;color:var(--text);font-size:13px;padding:12px 0;outline:none;flex:1;}
.si2 input::placeholder{color:var(--muted);}
.fr{display:flex;gap:7px;padding:10px 18px 4px;overflow-x:auto;flex-shrink:0;}
.fr::-webkit-scrollbar{display:none;}
.fc{flex-shrink:0;padding:6px 14px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.fc.on{background:var(--lime);color:#0D0F0A;}
.fc.off{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.08);}
.exc{background:var(--card);border-radius:16px;border:1px solid rgba(255,255,255,.04);overflow:hidden;display:flex;height:86px;margin-bottom:10px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.exc:active{border-color:var(--border);}
.ext{width:86px;flex-shrink:0;position:relative;display:flex;align-items:center;justify-content:center;font-size:30px;}
.pov{position:absolute;inset:0;background:rgba(0,0,0,.28);display:flex;align-items:center;justify-content:center;}
.pb{width:28px;height:28px;background:rgba(200,241,53,.9);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;color:#0D0F0A;padding-left:2px;}
.exb{padding:13px;flex:1;display:flex;flex-direction:column;justify-content:space-between;}
.exnm2{font-size:13px;font-weight:700;}
.exmt{display:flex;gap:6px;align-items:center;margin-top:4px;}
.exmu{font-size:10px;color:var(--muted);}
.exdur{font-size:10px;color:var(--muted);}

/* BUILDER */
.rnc{margin:14px 18px 0;background:var(--card2);border-radius:12px;border:1px solid var(--border);padding:14px;display:flex;align-items:center;gap:10px;font-size:16px;font-weight:700;color:var(--lime);}
.rnc .ei{margin-left:auto;font-size:15px;color:var(--muted);cursor:pointer;}
.bi2{background:var(--card);border:1px solid rgba(255,255,255,.04);border-radius:14px;padding:13px;display:flex;align-items:center;gap:10px;margin-bottom:8px;}
.dh{font-size:16px;color:var(--muted);}
.bi-ic{font-size:22px;}
.bi-inf{flex:1;}
.bi-nm{font-size:13px;font-weight:600;}
.bi-st{font-size:10px;color:var(--muted);margin-top:2px;}
.bi-ac{display:flex;gap:7px;}
.bb2{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:13px;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.be{background:rgba(200,241,53,.08);color:var(--lime);}
.bd{background:rgba(255,92,92,.08);color:var(--red);}
.addb{margin:0 18px;border:1.5px dashed rgba(200,241,53,.18);border-radius:14px;padding:14px;display:flex;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:600;color:var(--lime);opacity:.7;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.aisug{margin:12px 18px 0;background:linear-gradient(135deg,rgba(60,255,208,.07),rgba(200,241,53,.04));border:1px solid rgba(60,255,208,.14);border-radius:14px;padding:14px;display:flex;align-items:center;gap:10px;}
.aisug .si{font-size:22px;}
.aisug .sh2{font-size:11px;font-weight:700;color:var(--teal);}
.aisug .sp{font-size:10px;color:var(--muted);margin-top:2px;}
.aisug .sg{font-size:16px;color:var(--teal);cursor:pointer;margin-left:auto;padding:4px;}

/* SCHEDULE */
.mn2{display:flex;align-items:center;justify-content:space-between;padding:0 18px;margin-bottom:10px;}
.mnm{font-size:16px;font-weight:700;}
.ma{font-size:20px;color:var(--muted);cursor:pointer;padding:4px 8px;-webkit-tap-highlight-color:transparent;}
.dlb{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;font-size:9px;font-weight:700;letter-spacing:.8px;color:var(--muted);margin-bottom:6px;text-transform:uppercase;padding:0 18px;}
.cd2{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;padding:0 18px;margin-bottom:10px;}
.cd{aspect-ratio:1;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent;}
.cdw{background:rgba(200,241,53,.1);color:var(--lime);}
.cdr{background:rgba(255,155,66,.1);color:var(--orange);}
.cdt{border:1.5px solid var(--lime);}
.cds{background:var(--lime)!important;color:#0D0F0A!important;font-weight:800;}
.cdo{color:rgba(107,115,85,.45);}
.cle{display:flex;gap:16px;padding:10px 18px;border-top:1px solid var(--border);border-bottom:1px solid var(--border);margin-bottom:12px;}
.lg{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--muted);}
.lg-d{width:8px;height:8px;border-radius:50%;}
.wkitem{display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:12px;margin-bottom:6px;}
.wkw{background:rgba(200,241,53,.04);border:1px solid rgba(200,241,53,.1);}
.wkr{background:rgba(255,155,66,.04);border:1px solid rgba(255,155,66,.1);}
.wkday{font-size:11px;font-weight:700;width:28px;}
.wktype{flex:1;font-size:11px;color:var(--text2);}
.wkb{font-size:10px;font-weight:700;padding:3px 9px;border-radius:10px;}
.wkbw{background:rgba(200,241,53,.12);color:var(--lime);}
.wkbr{background:rgba(255,155,66,.12);color:var(--orange);}
.air{margin:0 18px;background:linear-gradient(135deg,rgba(255,155,66,.07),rgba(255,92,92,.04));border:1px solid rgba(255,155,66,.14);border-radius:14px;padding:14px;display:flex;gap:10px;}
.ar-h{font-size:11px;font-weight:700;color:var(--orange);}
.ar-p{font-size:10px;color:var(--muted);margin-top:3px;line-height:1.6;}

/* COACH */
#s-co .ca{flex:1;overflow-y:auto;padding:16px 18px;display:flex;flex-direction:column;gap:12px;-webkit-overflow-scrolling:touch;}
#s-co .ca::-webkit-scrollbar{display:none;}
.msg{max-width:82%;padding:12px 14px;border-radius:18px;font-size:13px;line-height:1.65;animation:fadeUp .28s ease both;}
.msg.ai{background:var(--card2);border:1px solid var(--border);border-radius:18px 18px 18px 4px;color:var(--text2);align-self:flex-start;}
.msg.ai b{color:var(--lime);}
.msg.user{background:var(--lime);color:#0D0F0A;font-weight:600;border-radius:18px 18px 4px 18px;align-self:flex-end;}
.msg.ld{background:var(--card2);border:1px solid var(--border);border-radius:18px 18px 18px 4px;align-self:flex-start;padding:16px 20px;}
.dots{display:flex;gap:5px;}
.dots span{width:7px;height:7px;background:var(--muted);border-radius:50%;animation:pulse 1.2s ease infinite;}
.dots span:nth-child(2){animation-delay:.2s;}
.dots span:nth-child(3){animation-delay:.4s;}
.qp{display:flex;gap:7px;flex-wrap:wrap;}
.qpill{padding:7px 13px;border-radius:20px;font-size:11px;font-weight:600;cursor:pointer;background:rgba(200,241,53,.08);border:1px solid rgba(200,241,53,.2);color:var(--lime);-webkit-tap-highlight-color:transparent;}
.cir{padding:10px 18px;padding-bottom:calc(10px + env(safe-area-inset-bottom,0px));border-top:1px solid var(--border);display:flex;gap:10px;align-items:flex-end;flex-shrink:0;}
.ci2{flex:1;background:var(--card2);border:1px solid var(--border);border-radius:12px;padding:12px 14px;color:var(--text);font-size:13px;outline:none;resize:none;max-height:90px;overflow-y:auto;line-height:1.4;}
.ci2::placeholder{color:var(--muted);}
.sb3{width:44px;height:44px;background:var(--lime);border:none;border-radius:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;-webkit-tap-highlight-color:transparent;transition:opacity .15s,transform .1s;}
.sb3:active{opacity:.8;transform:scale(.92);}
</style>
</head>
<body>
<div class="toast" id="toast"></div>

<!-- ONBOARD -->
<div class="screen active" id="s-ob">
  <div class="ob-in">
    <div class="ob-ic">&#9889;</div>
    <div class="ob-nm">Vitality AI</div>
    <div class="ob-tg">Your intelligent health companion</div>
    <div class="ob-fs">
      <div class="feat"><div class="feat-i">&#128247;</div><div><div class="feat-t">AI Food Scanner</div><div class="feat-s">Instant nutrition from your camera</div></div></div>
      <div class="feat"><div class="feat-i">&#127947;</div><div><div class="feat-t">Smart Workout Tracking</div><div class="feat-s">Custom routines with video demos</div></div></div>
      <div class="feat"><div class="feat-i">&#129504;</div><div><div class="feat-t">AI Nutrition Coach</div><div class="feat-s">Personalized insights powered by Claude</div></div></div>
      <div class="feat"><div class="feat-i">&#128197;</div><div><div class="feat-t">Rest Day Scheduler</div><div class="feat-s">Optimized recovery planning</div></div></div>
    </div>
    <div class="ob-bw"><button class="btn-lime" onclick="nav('home')">Get Started &#8594;</button></div>
  </div>
</div>

<!-- HOME -->
<div class="screen" id="s-home">
  <div class="sbar"><span class="t">9:41</span><span>&#9679;&#9679;&#9679; &#128267;</span></div>
  <div class="sbody">
    <div class="gr-row"><div><div class="gr-nm">Good morning, Alex &#128075;</div><div class="gr-sb">340 kcal remaining today</div></div><div class="av">A</div></div>
    <div class="rc">
      <svg width="90" height="90" viewBox="0 0 90 90" style="flex-shrink:0">
        <circle cx="45" cy="45" r="36" fill="none" stroke="#1C2016" stroke-width="10"/>
        <circle cx="45" cy="45" r="36" fill="none" stroke="url(#rg)" stroke-width="10" stroke-linecap="round" stroke-dasharray="226" stroke-dashoffset="62" transform="rotate(-90 45 45)"/>
        <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C8F135"/><stop offset="100%" stop-color="#3CFFD0"/></linearGradient></defs>
      </svg>
      <div style="flex:1">
        <div class="rs-big" id="total-kcal">1,460</div>
        <div class="rs-lb">of 1,800 kcal</div>
        <div class="mr">
          <div class="mcr"><div class="mcr-v" style="color:#C8F135">82g</div><div class="mcr-u">Protein</div></div>
          <div class="mcr"><div class="mcr-v" style="color:#3CFFD0">164g</div><div class="mcr-u">Carbs</div></div>
          <div class="mcr"><div class="mcr-v" style="color:#FF9B42">48g</div><div class="mcr-u">Fats</div></div>
        </div>
      </div>
    </div>
    <div class="qa">
      <div class="qac" onclick="nav('scan')"><div class="qa-i">&#128247;</div><div class="qa-l">Scan Food</div><div class="qa-s">AI recognition</div></div>
      <div class="qac" onclick="nav('workout')"><div class="qa-i">&#127947;</div><div class="qa-l">Start Workout</div><div class="qa-s">Today: Upper body</div></div>
      <div class="qac" onclick="nav('coach')"><div class="qa-i">&#129504;</div><div class="qa-l">AI Coach</div><div class="qa-s">Get insights</div></div>
      <div class="qac" onclick="nav('schedule')"><div class="qa-i">&#128197;</div><div class="qa-l">Schedule</div><div class="qa-s">Rest day planner</div></div>
    </div>
    <div class="wc"><div class="wh"><span>&#128167; Water Intake</span><span style="color:var(--teal);font-size:12px;font-weight:700">1.5L / 2.5L</span></div><div class="wtr"><div class="wf"></div></div></div>
    <div class="ph"><div class="sec-h"><h3>Today's Meals</h3><span onclick="nav('scan')">+ Add</span></div></div>
    <div class="ph" id="meal-list">
      <div class="mi"><span class="me">&#129379;</span><div style="flex:1"><div class="mn">Overnight Oats</div><div class="mt">7:30 AM &middot; Breakfast</div></div><span class="mk">380</span></div>
      <div class="mi"><span class="me">&#129401;</span><div style="flex:1"><div class="mn">Grilled Chicken Salad</div><div class="mt">12:45 PM &middot; Lunch</div></div><span class="mk">520</span></div>
      <div class="mi"><span class="me">&#127822;</span><div style="flex:1"><div class="mn">Apple + Almonds</div><div class="mt">3:00 PM &middot; Snack</div></div><span class="mk">210</span></div>
      <div class="mi" onclick="nav('nutrition')"><span class="me">&#128202;</span><div style="flex:1"><div class="mn" style="color:var(--lime)">View Nutrition Insights</div><div class="mt">AI-powered analysis</div></div><span style="color:var(--muted);font-size:18px">&#8594;</span></div>
    </div>
    <div style="height:16px"></div>
  </div>
  <div class="bnav">
    <div class="ni active" onclick="nav('home')"><div class="ni-i">&#127968;</div><div>Home</div></div>
    <div class="ni" onclick="nav('scan')"><div class="ni-i">&#128247;</div><div>Scan</div></div>
    <div class="ni" onclick="nav('workout')"><div class="ni-i">&#127947;</div><div>Workout</div></div>
    <div class="ni" onclick="nav('library')"><div class="ni-i">&#128218;</div><div>Library</div></div>
    <div class="ni" onclick="nav('coach')"><div class="ni-i">&#129504;</div><div>Coach</div></div>
  </div>
</div>

<!-- SCAN -->
<div class="screen" id="s-sc">
  <div class="cam"></div>
  <div class="sh"><div class="bk" onclick="nav('home')">&#8592;</div><span style="font-size:18px;font-weight:700;color:#fff;font-family:sans-serif">Scan Food</span><div class="pill pl" style="margin-left:auto">AI Active</div></div>
  <div class="sf"><div class="sfc tl"></div><div class="sfc tr"></div><div class="sfc bl"></div><div class="sfc br"></div><div class="sb"></div></div>
  <div class="dl" id="det-lbl">&#127829; Chicken Detected</div>
  <div class="sct">
    <div class="ci">&#9889;</div>
    <div class="shu" onclick="doScan()">&#128247;</div>
    <div class="ci">&#128444;</div>
  </div>
  <div class="rs" id="rsheet">
    <div class="dp"></div>
    <div class="ft" id="rs-title">Grilled Chicken Breast</div>
    <div class="cf">&#10022; <span id="rs-conf">97% confidence</span> &middot; 100g serving</div>
    <div class="ng">
      <div class="nb"><div class="nv" style="color:#C8F135" id="rs-kcal">165</div><div class="nl">kcal</div></div>
      <div class="nb"><div class="nv" style="color:#3CFFD0" id="rs-prot">31g</div><div class="nl">protein</div></div>
      <div class="nb"><div class="nv" style="color:#FF9B42" id="rs-fat">3.6g</div><div class="nl">fat</div></div>
      <div class="nb"><div class="nv" id="rs-carb">0g</div><div class="nl">carbs</div></div>
    </div>
    <button class="btn-lime" onclick="addMeal()">+ Add to Meal Log</button>
  </div>
</div>

<!-- MANUAL FOOD ENTRY -->
<div class="screen" id="s-manual">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="tbar"><span class="back" onclick="nav('scan')">&#8592;</span><h2>Add Food Manually</h2></div>
  <div class="sbody" style="padding:16px 18px 20px">
    <div class="inp-row"><label>Food Name</label><input class="inp" id="m-name" placeholder="e.g. Grilled Salmon"></div>
    <div class="inp-grid">
      <div class="inp-row"><label>Calories (kcal)</label><input class="inp" id="m-kcal" type="number" placeholder="0"></div>
      <div class="inp-row"><label>Protein (g)</label><input class="inp" id="m-prot" type="number" placeholder="0"></div>
    </div>
    <div class="inp-grid">
      <div class="inp-row"><label>Carbs (g)</label><input class="inp" id="m-carb" type="number" placeholder="0"></div>
      <div class="inp-row"><label>Fat (g)</label><input class="inp" id="m-fat" type="number" placeholder="0"></div>
    </div>
    <div class="inp-row"><label>Meal Time</label>
      <select class="inp" id="m-time">
        <option>Breakfast</option><option>Lunch</option><option>Dinner</option><option>Snack</option>
      </select>
    </div>
    <button class="btn-lime" onclick="addManual()">Add to Meal Log</button>
  </div>
</div>

<!-- NUTRITION -->
<div class="screen" id="s-nt">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="tbar"><span class="back" onclick="nav('home')">&#8592;</span><h2>Nutrition Insight</h2><div class="pill pl">Today</div></div>
  <div class="sbody" style="padding-bottom:20px">
    <div style="height:14px"></div>
    <div class="aic">
      <div class="aih"><div class="aiav">V</div><div class="ainm">Vitality AI</div><div class="pill pt" style="margin-left:auto;font-size:9px">Live</div></div>
      <div id="nutr-ai"><div class="ald"><div class="asp"></div> Analyzing your nutrition&hellip;</div></div>
    </div>
    <div class="ph" style="margin-bottom:16px">
      <div class="sec-h"><h3>Macros Breakdown</h3></div>
      <div class="br-row"><div class="bl">Protein</div><div class="btr"><div class="bf" style="width:82%;background:linear-gradient(90deg,#C8F135,#a8cc1a)"></div></div><div class="bv" style="color:#C8F135">82g</div></div>
      <div class="br-row"><div class="bl">Carbs</div><div class="btr"><div class="bf" style="width:68%;background:linear-gradient(90deg,#3CFFD0,#1ab88f)"></div></div><div class="bv" style="color:#3CFFD0">164g</div></div>
      <div class="br-row"><div class="bl">Fat</div><div class="btr"><div class="bf" style="width:54%;background:linear-gradient(90deg,#FF9B42,#e07730)"></div></div><div class="bv" style="color:#FF9B42">48g</div></div>
      <div class="br-row"><div class="bl">Fiber</div><div class="btr"><div class="bf" style="width:40%;background:linear-gradient(90deg,#FF5C5C,#cc3a3a)"></div></div><div class="bv" style="color:#FF5C5C">12g</div></div>
      <div class="br-row"><div class="bl">Water</div><div class="btr"><div class="bf" style="width:60%;background:linear-gradient(90deg,#5b9fff,#3a7fdd)"></div></div><div class="bv" style="color:#5b9fff">1.5L</div></div>
    </div>
    <div class="scr">
      <div class="scc"><div class="scn" style="color:#C8F135">84</div><div class="scl">Nutrition</div></div>
      <div class="scc"><div class="scn" style="color:#3CFFD0">72</div><div class="scl">Hydration</div></div>
      <div class="scc"><div class="scn" style="color:#FF9B42">91</div><div class="scl">Protein</div></div>
    </div>
    <div class="ph" style="margin-bottom:4px"><div class="sec-h"><h3>Micronutrients</h3></div></div>
    <div class="mch">
      <span class="mc mcg">&#10003; Vitamin D</span><span class="mc mcg">&#10003; Iron</span>
      <span class="mc mcw">&#9888; Omega-3</span><span class="mc mcg">&#10003; Calcium</span>
      <span class="mc mcw">&#9888; Magnesium</span><span class="mc mcg">&#10003; Zinc</span>
      <span class="mc mcw">&#9888; Vitamin B12</span><span class="mc mcg">&#10003; Potassium</span>
    </div>
  </div>
</div>

<!-- WORKOUT -->
<div class="screen" id="s-wk">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="sbody" style="padding-bottom:calc(130px + env(safe-area-inset-bottom,0px))">
    <div class="wkh"><h2>Upper Body &#128170;</h2><div class="wkd">Today &middot; Push Day</div><div class="lb"><div class="ld"></div> Live Session</div></div>
    <div class="tw">
      <svg width="120" height="120" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="50" fill="none" stroke="#1C2016" stroke-width="11"/>
        <circle cx="60" cy="60" r="50" fill="none" stroke="url(#tg)" stroke-width="11" stroke-linecap="round" stroke-dasharray="314" stroke-dashoffset="86" transform="rotate(-90 60 60)"/>
        <defs><linearGradient id="tg" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#C8F135"/><stop offset="100%" stop-color="#3CFFD0"/></linearGradient></defs>
      </svg>
      <div class="tc"><div class="tb" id="timer">24:18</div><div class="ts">elapsed</div></div>
    </div>
    <div class="str">
      <div class="sb2"><div class="sv" style="color:#C8F135">312</div><div class="sl">kcal</div></div>
      <div class="sb2"><div class="sv" style="color:#3CFFD0" id="ex-prog">4/6</div><div class="sl">exercises</div></div>
      <div class="sb2"><div class="sv" style="color:#FF9B42">148</div><div class="sl">bpm</div></div>
    </div>
    <div class="ph"><div class="sec-h"><h3>Exercises</h3><span id="done-lbl">4 of 6 done</span></div></div>
    <div class="ph" id="ex-list">
      <div class="exi"><div class="exn ed">&#10003;</div><div style="flex:1"><div class="exnm">Bench Press</div><div class="exst">4 sets &middot; 60kg &middot; Done</div></div><div class="exi-i">&#128170;</div></div>
      <div class="exi"><div class="exn ed">&#10003;</div><div style="flex:1"><div class="exnm">Overhead Press</div><div class="exst">3 sets &middot; 40kg &middot; Done</div></div><div class="exi-i">&#128077;</div></div>
      <div class="exi"><div class="exn ed">&#10003;</div><div style="flex:1"><div class="exnm">Push-Ups</div><div class="exst">3 sets &middot; Bodyweight &middot; Done</div></div><div class="exi-i">&#129328;</div></div>
      <div class="exi"><div class="exn ed">&#10003;</div><div style="flex:1"><div class="exnm">Dumbbell Flyes</div><div class="exst">3 sets &middot; 15kg &middot; Done</div></div><div class="exi-i">&#127941;</div></div>
      <div class="exi curr" id="curr-ex"><div class="exn ec">5</div><div style="flex:1"><div class="exnm">Tricep Dips</div><div class="exst">3 sets &middot; Bodyweight &middot; In Progress</div></div><div class="exi-i">&#9889;</div></div>
      <div class="exi" id="next-ex"><div class="exn en">6</div><div style="flex:1"><div class="exnm">Lateral Raises</div><div class="exst">3 sets &middot; 10kg &middot; Up next</div></div><div class="exi-i">&#127947;</div></div>
    </div>
  </div>
  <div style="position:absolute;bottom:calc(62px + env(safe-area-inset-bottom,0px));left:0;right:0;padding:10px 18px;background:var(--dark2);border-top:1px solid var(--border);">
    <div class="cr" style="padding:0">
      <div class="cp" onclick="toast('Workout paused')">&#9208; Pause</div>
      <button class="cn" onclick="nextEx()">Next Exercise &#8594;</button>
    </div>
  </div>
  <div class="bnav">
    <div class="ni" onclick="nav('home')"><div class="ni-i">&#127968;</div><div>Home</div></div>
    <div class="ni" onclick="nav('scan')"><div class="ni-i">&#128247;</div><div>Scan</div></div>
    <div class="ni active"><div class="ni-i">&#127947;</div><div>Workout</div></div>
    <div class="ni" onclick="nav('library')"><div class="ni-i">&#128218;</div><div>Library</div></div>
    <div class="ni" onclick="nav('coach')"><div class="ni-i">&#129504;</div><div>Coach</div></div>
  </div>
</div>

<!-- LIBRARY -->
<div class="screen" id="s-lb">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="lh"><h2>Exercise Library</h2><div class="si2"><span style="font-size:14px;color:var(--muted)">&#128269;</span><input type="text" placeholder="Search exercises..." id="lib-search" oninput="filterLib()"></div></div>
  <div class="fr" id="frow">
    <div class="fc on" onclick="setF(this,'All')">All</div>
    <div class="fc off" onclick="setF(this,'Chest')">Chest</div>
    <div class="fc off" onclick="setF(this,'Back')">Back</div>
    <div class="fc off" onclick="setF(this,'Legs')">Legs</div>
    <div class="fc off" onclick="setF(this,'Arms')">Arms</div>
    <div class="fc off" onclick="setF(this,'Core')">Core</div>
    <div class="fc off" onclick="setF(this,'Shoulders')">Shoulders</div>
  </div>
  <div class="sbody" style="padding:0 18px calc(72px + env(safe-area-inset-bottom,0px));" id="lib-list"></div>
  <div class="bnav">
    <div class="ni" onclick="nav('home')"><div class="ni-i">&#127968;</div><div>Home</div></div>
    <div class="ni" onclick="nav('scan')"><div class="ni-i">&#128247;</div><div>Scan</div></div>
    <div class="ni" onclick="nav('workout')"><div class="ni-i">&#127947;</div><div>Workout</div></div>
    <div class="ni active"><div class="ni-i">&#128218;</div><div>Library</div></div>
    <div class="ni" onclick="nav('coach')"><div class="ni-i">&#129504;</div><div>Coach</div></div>
  </div>
</div>

<!-- BUILDER -->
<div class="screen" id="s-bd">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="tbar"><span class="back" onclick="nav('workout')">&#8592;</span><h2>Build Routine</h2></div>
  <div class="sbody" style="padding-bottom:20px">
    <div class="rnc">&#128293; My Push Day<span class="ei">&#9998;</span></div>
    <div style="padding:14px 18px 0" id="build-list">
      <div class="bi2"><span class="dh">&#8942;</span><span class="bi-ic">&#127947;</span><div class="bi-inf"><div class="bi-nm">Bench Press</div><div class="bi-st">4 x 8-10 reps &middot; 60kg</div></div><div class="bi-ac"><div class="bb2 be">&#9998;</div><div class="bb2 bd" onclick="rmEx(this)">&#10005;</div></div></div>
      <div class="bi2"><span class="dh">&#8942;</span><span class="bi-ic">&#128077;</span><div class="bi-inf"><div class="bi-nm">Overhead Press</div><div class="bi-st">3 x 8 reps &middot; 40kg</div></div><div class="bi-ac"><div class="bb2 be">&#9998;</div><div class="bb2 bd" onclick="rmEx(this)">&#10005;</div></div></div>
      <div class="bi2"><span class="dh">&#8942;</span><span class="bi-ic">&#128170;</span><div class="bi-inf"><div class="bi-nm">Tricep Dips</div><div class="bi-st">3 x 12 reps &middot; Bodyweight</div></div><div class="bi-ac"><div class="bb2 be">&#9998;</div><div class="bb2 bd" onclick="rmEx(this)">&#10005;</div></div></div>
    </div>
    <div class="addb" onclick="toast('Go to Library to add exercises')">+ Add Exercise from Library</div>
    <div class="aisug"><span class="si">&#129302;</span><div style="flex:1"><div class="sh2">AI Suggestion</div><div class="sp">Add cable flyes to complete chest activation</div></div><span class="sg" onclick="addAI()">&#8594;</span></div>
    <div style="padding:14px 18px 0"><button class="btn-lime" onclick="saveRoutine()">Save Routine &#10003;</button></div>
  </div>
</div>

<!-- SCHEDULE -->
<div class="screen" id="s-sd">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div style="padding:8px 18px 10px;flex-shrink:0"><div style="font-size:22px;font-weight:800">Schedule &amp; Recovery</div><div style="font-size:11px;color:var(--muted);margin-top:3px">Plan your training &amp; rest cycle</div></div>
  <div class="sbody" style="padding-bottom:calc(72px + env(safe-area-inset-bottom,0px))">
    <div class="mn2"><span class="ma">&#8249;</span><span class="mnm">May 2026</span><span class="ma">&#8250;</span></div>
    <div class="dlb"><span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span></div>
    <div class="cd2" id="caldays"></div>
    <div class="cle">
      <div class="lg"><div class="lg-d" style="background:#C8F135"></div>Workout</div>
      <div class="lg"><div class="lg-d" style="background:#FF9B42"></div>Rest Day</div>
      <div class="lg"><div class="lg-d" style="background:#C8F135;border:1.5px solid #fff"></div>Today</div>
    </div>
    <div class="ph"><div class="sec-h"><h3>This Week</h3></div></div>
    <div class="ph">
      <div class="wkitem wkw"><span class="wkday">Mon</span><span class="wktype">Upper Body Push</span><span class="wkb wkbw">Workout</span></div>
      <div class="wkitem wkw"><span class="wkday">Tue</span><span class="wktype">Lower Body Pull</span><span class="wkb wkbw">Workout</span></div>
      <div class="wkitem wkw"><span class="wkday">Wed</span><span class="wktype">Full Body HIIT</span><span class="wkb wkbw">Workout</span></div>
      <div class="wkitem wkr"><span class="wkday">Thu</span><span class="wktype">Active Recovery</span><span class="wkb wkbr">Rest</span></div>
      <div class="wkitem wkw"><span class="wkday">Fri</span><span class="wktype">Upper Body Pull</span><span class="wkb wkbw">Workout</span></div>
      <div class="wkitem wkr"><span class="wkday">Sat</span><span class="wktype">Complete Rest</span><span class="wkb wkbr">Rest</span></div>
      <div class="wkitem wkw"><span class="wkday" style="color:var(--lime)">Sun</span><span class="wktype">Today &middot; Push Day</span><span class="wkb wkbw">Workout</span></div>
    </div>
    <div style="height:12px"></div>
    <div class="air"><span style="font-size:20px;flex-shrink:0">&#129504;</span><div><div class="ar-h">AI Recovery Insight</div><div class="ar-p">You've trained 3 days straight. Thursday is scheduled as rest — your muscles need 48h for optimal adaptation and growth.</div></div></div>
    <div style="height:16px"></div>
  </div>
  <div class="bnav">
    <div class="ni" onclick="nav('home')"><div class="ni-i">&#127968;</div><div>Home</div></div>
    <div class="ni" onclick="nav('scan')"><div class="ni-i">&#128247;</div><div>Scan</div></div>
    <div class="ni active"><div class="ni-i">&#127947;</div><div>Workout</div></div>
    <div class="ni" onclick="nav('library')"><div class="ni-i">&#128218;</div><div>Library</div></div>
    <div class="ni" onclick="nav('coach')"><div class="ni-i">&#129504;</div><div>Coach</div></div>
  </div>
</div>

<!-- COACH -->
<div class="screen" id="s-co">
  <div class="sbar"><span class="t">9:41</span><span>&#128267;</span></div>
  <div class="tbar"><span class="back" onclick="nav('home')">&#8592;</span><h2>AI Nutrition Coach</h2><div class="pill pt" style="font-size:9px">Claude AI</div></div>
  <div class="ca" id="chat-area">
    <div class="msg ai">&#128075; Hi Alex! I'm your <b>Vitality AI coach</b>, powered by Claude. Ask me anything about nutrition, workouts, or recovery!</div>
    <div class="qp">
      <div class="qpill" onclick="qMsg('How am I doing with my nutrition today?')">Today's nutrition?</div>
      <div class="qpill" onclick="qMsg('What should I eat after my workout?')">Post-workout meal?</div>
      <div class="qpill" onclick="qMsg('How many rest days do I need per week?')">Rest day advice?</div>
    </div>
  </div>
  <div class="cir">
    <textarea class="ci2" id="cinput" placeholder="Ask about nutrition, workouts, recovery..." rows="1"
      onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendMsg();}"></textarea>
    <button class="sb3" onclick="sendMsg()">&#8679;</button>
  </div>
  <div class="bnav">
    <div class="ni" onclick="nav('home')"><div class="ni-i">&#127968;</div><div>Home</div></div>
    <div class="ni" onclick="nav('scan')"><div class="ni-i">&#128247;</div><div>Scan</div></div>
    <div class="ni" onclick="nav('workout')"><div class="ni-i">&#127947;</div><div>Workout</div></div>
    <div class="ni" onclick="nav('library')"><div class="ni-i">&#128218;</div><div>Library</div></div>
    <div class="ni active"><div class="ni-i">&#129504;</div><div>Coach</div></div>
  </div>
</div>

<script>
const ST={meals:[{e:'&#129379;',n:'Overnight Oats',t:'7:30 AM &middot; Breakfast',k:380},{e:'&#129401;',n:'Grilled Chicken Salad',t:'12:45 PM &middot; Lunch',k:520},{e:'&#127822;',n:'Apple + Almonds',t:'3:00 PM &middot; Snack',k:210}],chatHist:[],exDone:4,totalEx:6,timerSec:24*60+18,timerOn:false,timerInt:null,curFilter:'All',curScan:null};
const FOODS=[
  {lbl:'&#127829; Chicken Detected',title:'Grilled Chicken Breast',conf:'97% confidence',kcal:'165',prot:'31g',fat:'3.6g',carb:'0g',e:'&#127829;'},
  {lbl:'&#129401; Salad Detected',title:'Caesar Salad',conf:'91% confidence',kcal:'220',prot:'8g',fat:'14g',carb:'18g',e:'&#129401;'},
  {lbl:'&#127820; Banana Detected',title:'Banana (Medium)',conf:'99% confidence',kcal:'89',prot:'1.1g',fat:'0.3g',carb:'23g',e:'&#127820;'},
  {lbl:'&#129379; Eggs Detected',title:'Scrambled Eggs (2)',conf:'95% confidence',kcal:'182',prot:'12g',fat:'14g',carb:'2g',e:'&#129379;'},
  {lbl:'&#127859; Rice Detected',title:'Brown Rice (cooked)',conf:'88% confidence',kcal:'216',prot:'5g',fat:'1.8g',carb:'45g',e:'&#127859;'},
];
const EXLIB=[
  {n:'Barbell Bench Press',m:'Chest',l:'Intermediate',e:'&#127947;',d:'2:34',s:'4 sets &middot; 6-12 reps',bg:'#1C2A10'},
  {n:'Push-Up Variations',m:'Full Body',l:'Beginner',e:'&#128170;',d:'1:48',s:'3 sets &middot; 15-20 reps',bg:'#102A20'},
  {n:'Overhead Press',m:'Shoulders',l:'Intermediate',e:'&#128077;',d:'3:10',s:'4 sets &middot; 8-10 reps',bg:'#2A1010'},
  {n:'Tricep Pushdown',m:'Arms',l:'Beginner',e:'&#9889;',d:'1:55',s:'3 sets &middot; 12-15 reps',bg:'#0A1A2A'},
  {n:'Pull-Ups',m:'Back',l:'Intermediate',e:'&#127941;',d:'2:20',s:'4 sets &middot; 6-10 reps',bg:'#1A0A2A'},
  {n:'Barbell Squat',m:'Legs',l:'Beginner',e:'&#129464;',d:'3:00',s:'4 sets &middot; 8-12 reps',bg:'#2A1A00'},
  {n:'Deadlift',m:'Back',l:'Advanced',e:'&#9881;',d:'3:45',s:'3 sets &middot; 5 reps',bg:'#1A1A0A'},
  {n:'Cable Flyes',m:'Chest',l:'Beginner',e:'&#128279;',d:'1:30',s:'3 sets &middot; 15 reps',bg:'#0A2A10'},
  {n:'Bicep Curls',m:'Arms',l:'Beginner',e:'&#128171;',d:'1:40',s:'3 sets &middot; 12 reps',bg:'#200A1A'},
  {n:'Plank Hold',m:'Core',l:'Beginner',e:'&#129503;',d:'1:15',s:'3 sets &middot; 60 sec',bg:'#0A1A1A'},
  {n:'Leg Press',m:'Legs',l:'Beginner',e:'&#129464;',d:'2:10',s:'4 sets &middot; 10-12 reps',bg:'#1A1000'},
  {n:'Lateral Raises',m:'Shoulders',l:'Beginner',e:'&#127944;',d:'1:50',s:'3 sets &middot; 15 reps',bg:'#001A1A'},
];
const MCLS={Chest:'pl','Full Body':'pt',Shoulders:'po',Arms:'pr',Back:'pl',Legs:'po',Core:'pt'};
const MAP={'home':'s-home','scan':'s-sc','nutrition':'s-nt','workout':'s-wk','library':'s-lb','builder':'s-bd','schedule':'s-sd','coach':'s-co','manual':'s-manual'};

function nav(s){
  document.querySelectorAll('.screen').forEach(el=>{el.classList.remove('active');el.style.display='none';});
  const el=document.getElementById(MAP[s]||('s-'+s));if(!el)return;
  el.style.display='flex';requestAnimationFrame(()=>el.classList.add('active'));
  if(s==='scan')initScan();
  if(s==='nutrition')loadNutrAI();
  if(s==='library')renderLib();
  if(s==='schedule')renderCal();
  if(s==='workout'&&!ST.timerOn)startTimer();
}

function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400);}

let scanT;
function initScan(){
  document.getElementById('rsheet').classList.remove('open');
  document.getElementById('det-lbl').classList.remove('show');
  clearTimeout(scanT);
  scanT=setTimeout(()=>{
    const f=FOODS[Math.floor(Math.random()*FOODS.length)];ST.curScan=f;
    document.getElementById('det-lbl').innerHTML=f.lbl;
    document.getElementById('det-lbl').classList.add('show');
  },1800);
}

function doScan(){
  if(!ST.curScan)ST.curScan=FOODS[Math.floor(Math.random()*FOODS.length)];
  const f=ST.curScan;
  document.getElementById('rs-title').textContent=f.title;
  document.getElementById('rs-conf').textContent=f.conf;
  document.getElementById('rs-kcal').textContent=f.kcal;
  document.getElementById('rs-prot').textContent=f.prot;
  document.getElementById('rs-fat').textContent=f.fat;
  document.getElementById('rs-carb').textContent=f.carb;
  document.getElementById('rsheet').classList.add('open');
}

function addMeal(){
  if(!ST.curScan)return;
  const f=ST.curScan;
  ST.meals.push({e:f.e,n:f.title,t:'Just now &middot; Scanned',k:parseInt(f.kcal)});
  renderMeals();document.getElementById('rsheet').classList.remove('open');
  toast('Added: '+f.title);setTimeout(()=>nav('home'),500);ST.curScan=null;
}

function addManual(){
  const n=document.getElementById('m-name').value.trim();
  const k=parseInt(document.getElementById('m-kcal').value)||0;
  const t=document.getElementById('m-time').value;
  if(!n){toast('Please enter a food name');return;}
  ST.meals.push({e:'&#127859;',n,t:'Just now &middot; '+t,k});
  renderMeals();toast('Added: '+n);setTimeout(()=>nav('home'),400);
}

function renderMeals(){
  const el=document.getElementById('meal-list');if(!el)return;
  const total=ST.meals.reduce((a,m)=>a+m.k,0);
  const tk=document.getElementById('total-kcal');if(tk)tk.textContent=total.toLocaleString();
  el.innerHTML=ST.meals.map(m=>`<div class="mi"><span class="me">${m.e}</span><div style="flex:1"><div class="mn">${m.n}</div><div class="mt">${m.t}</div></div><span class="mk">${m.k}</span></div>`).join('')+
  `<div class="mi" onclick="nav('scan')"><span class="me">&#128247;</span><div style="flex:1"><div class="mn" style="color:var(--lime)">Scan Food</div><div class="mt">Add from camera</div></div><span style="color:var(--muted);font-size:18px">&#8594;</span></div>
   <div class="mi" onclick="nav('manual')"><span class="me">&#9998;</span><div style="flex:1"><div class="mn" style="color:var(--lime)">Add Manually</div><div class="mt">Enter nutrition info</div></div><span style="color:var(--muted);font-size:18px">&#8594;</span></div>
   <div class="mi" onclick="nav('nutrition')"><span class="me">&#128202;</span><div style="flex:1"><div class="mn" style="color:var(--lime)">View Nutrition Insights</div><div class="mt">AI-powered analysis</div></div><span style="color:var(--muted);font-size:18px">&#8594;</span></div>`;
}

async function loadNutrAI(){
  const el=document.getElementById('nutr-ai');
  el.innerHTML='<div class="ald"><div class="asp"></div> Analyzing your nutrition&hellip;</div>';
  const kcal=ST.meals.reduce((a,m)=>a+m.k,0);
  const names=ST.meals.map(m=>m.n).join(', ');
  try{
    const r=await fetch('/api/coach',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:`My meals today: ${names}. Total: ${kcal} kcal. Goal: 1800 kcal. Give me a brief personalized nutrition insight in 2-3 sentences.`,history:[]})});
    const d=await r.json();
    el.innerHTML='<p>'+fmt(d.reply||'')+'</p>';
  }catch(e){
    el.innerHTML=`<p>You're at <b>${kcal} kcal</b> today with <b>${Math.max(0,1800-kcal)} kcal remaining</b>. Your protein intake looks excellent! Consider adding more leafy greens to boost your micronutrient profile.</p>`;
  }
}

function fmt(t){return t.replace(/\*\*(.*?)\*\*/g,'<b>$1</b>').replace(/\*(.*?)\*/g,'<em>$1</em>');}

function startTimer(){
  ST.timerOn=true;
  ST.timerInt=setInterval(()=>{
    ST.timerSec++;
    const m=Math.floor(ST.timerSec/60),s=ST.timerSec%60;
    const el=document.getElementById('timer');
    if(el)el.textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  },1000);
}

function nextEx(){
  if(ST.exDone>=ST.totalEx){toast('Workout complete!');return;}
  ST.exDone++;
  const curr=document.getElementById('curr-ex');
  if(curr){curr.querySelector('.exn').className='exn ed';curr.querySelector('.exn').innerHTML='&#10003;';curr.querySelector('.exst').textContent=curr.querySelector('.exst').textContent.replace('In Progress','Done');curr.classList.remove('curr');}
  const nxt=document.getElementById('next-ex');
  if(nxt){nxt.querySelector('.exn').className='exn ec';nxt.querySelector('.exn').textContent=ST.exDone+1;nxt.querySelector('.exst').textContent=nxt.querySelector('.exst').textContent.replace('Up next','In Progress');nxt.classList.add('curr');nxt.id='curr-ex';}
  const p=document.getElementById('ex-prog'),l=document.getElementById('done-lbl');
  if(p)p.textContent=ST.exDone+'/'+ST.totalEx;if(l)l.textContent=ST.exDone+' of '+ST.totalEx+' done';
  if(ST.exDone>=ST.totalEx)toast('Last exercise! Almost there!');
}

function renderLib(filter,search){
  filter=filter||ST.curFilter;search=search||(document.getElementById('lib-search')?.value?.toLowerCase()||'');
  const el=document.getElementById('lib-list');if(!el)return;
  const f=EXLIB.filter(e=>(filter==='All'||e.m===filter)&&(!search||e.n.toLowerCase().includes(search)||e.m.toLowerCase().includes(search)));
  el.innerHTML=f.map(e=>`<div class="exc" onclick="toast('Playing: ${e.n}')"><div class="ext" style="background:${e.bg}"><span>${e.e}</span><div class="pov"><div class="pb">&#9654;</div></div></div><div class="exb"><div><div class="exnm2">${e.n}</div><div class="exmt"><span class="pill ${MCLS[e.m]||'pl'}" style="font-size:9px;padding:2px 7px">${e.m}</span><span class="exmu">${e.l}</span></div></div><div class="exdur">&#9654; ${e.d} &middot; ${e.s}</div></div></div>`).join('')||'<div style="text-align:center;color:var(--muted);padding:40px 0;font-size:13px">No exercises found</div>';
}
function setF(el,v){document.querySelectorAll('.fc').forEach(c=>{c.classList.remove('on');c.classList.add('off');});el.classList.remove('off');el.classList.add('on');ST.curFilter=v;renderLib(v);}
function filterLib(){renderLib(ST.curFilter);}

function rmEx(btn){btn.closest('.bi2').remove();toast('Exercise removed');}
function addAI(){const l=document.getElementById('build-list');const d=document.createElement('div');d.className='bi2';d.style.animation='fadeUp .3s ease both';d.innerHTML='<span class="dh">&#8942;</span><span class="bi-ic">&#128279;</span><div class="bi-inf"><div class="bi-nm">Cable Flyes</div><div class="bi-st">3 x 15 reps &middot; 15kg</div></div><div class="bi-ac"><div class="bb2 be">&#9998;</div><div class="bb2 bd" onclick="rmEx(this)">&#10005;</div></div>';l.appendChild(d);toast('Cable Flyes added by AI!');}
function saveRoutine(){toast('Routine saved!');setTimeout(()=>nav('workout'),700);}

function renderCal(){
  const el=document.getElementById('caldays');if(!el)return;
  const types={1:'w',2:'r',3:'w',4:'w',5:'w',6:'r',7:'w',8:'r',9:'w',10:'w',11:'w',12:'r',13:'w',14:'r',15:'w',16:'w',17:'w',18:'r',19:'w',20:'r',21:'w',22:'w',23:'w',24:'w',25:'r'};
  let h='<div style="aspect-ratio:1"></div>'.repeat(5);
  for(let d=1;d<=31;d++){
    const t=types[d];let cls='cd';
    if(d>25)cls+=' cdo';else if(t==='w')cls+=' cdw';else if(t==='r')cls+=' cdr';
    if(d===25)cls+=' cdt cds';
    h+=`<div class="${cls}" onclick="toast('${d} May - ${t==='w'?'Workout':t==='r'?'Rest Day':'Plan'}')">${d}</div>`;
  }
  el.innerHTML=h;
}

async function sendMsg(){
  const inp=document.getElementById('cinput');const txt=inp.value.trim();if(!txt)return;
  inp.value='';inp.style.height='auto';
  addMsg(txt,'user');ST.chatHist.push({role:'user',content:txt});
  const ld=addMsg('','ld');
  try{
    const r=await fetch('/api/coach',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:txt,history:ST.chatHist.slice(-8)})});
    const d=await r.json();const rep=d.reply||"I'm having trouble connecting.";
    ld.remove();addMsg(fmt(rep),'ai');ST.chatHist.push({role:'assistant',content:rep});
  }catch(e){
    ld.remove();
    const fb=["Based on your meals today, you're at <b>"+ST.meals.reduce((a,m)=>a+m.k,0)+" kcal</b>. A balanced dinner will hit your goal!","Post-workout, aim for a <b>3:1 carb-to-protein ratio</b> within 30 minutes. Greek yogurt with banana works great!","Aim for <b>1-2 rest days per week</b>. Your schedule shows Thursday as recovery day — that's ideal!"];
    addMsg(fmt(fb[Math.floor(Math.random()*fb.length)]),'ai');
  }
  scrollChat();
}
function qMsg(t){document.getElementById('cinput').value=t;sendMsg();}
function addMsg(txt,type){const a=document.getElementById('chat-area');const d=document.createElement('div');d.className='msg '+type;if(type==='ld')d.innerHTML='<div class="dots"><span></span><span></span><span></span></div>';else d.innerHTML=txt;a.appendChild(d);scrollChat();return d;}
function scrollChat(){const a=document.getElementById('chat-area');if(a)setTimeout(()=>a.scrollTop=a.scrollHeight,60);}

renderLib();renderCal();
</script>
</body>
</html>"""

@app.route('/')
def index():
    from flask import Response
    return Response(render_template_string(HTML), content_type="text/html; charset=utf-8")

@app.route('/api/coach', methods=['POST'])
def coach():
    data = request.json
    message = data.get('message', '')
    history = data.get('history', [])

    messages = [m for m in history if m.get('role') in ['user','assistant']]
    if not messages or messages[-1].get('content') != message:
        messages.append({"role": "user", "content": message})

    # Try Claude API first
    try:
        resp = requests.post(
            CLAUDE_API_URL,
            headers={
                "Content-Type": "application/json",
                "x-api-key": API_KEY,
                "anthropic-version": "2023-06-01"
            },
            json={
                "model": CLAUDE_MODEL,
                "max_tokens": 1000,
                "system": "You are Vitality AI, a friendly fitness and nutrition coach in a mobile health app. The user is Alex. Be concise (2-4 sentences), warm, and actionable. Use **bold** for key terms. Never use bullet points.",
                "messages": messages
            },
            timeout=10
        )
        result = resp.json()
        if 'content' in result:
            reply = result['content'][0].get('text', '')
            if reply:
                return jsonify({"reply": reply})
    except Exception:
        pass

    # Smart fallback responses
    msg = message.lower()
    if any(w in msg for w in ['nutrition','eating','diet','meal','food','calorie']):
        reply = "Your **protein intake looks great** today! You have around 340 kcal remaining. Try adding a balanced dinner with lean protein and complex carbs to hit your 1800 kcal goal. **Hydration** is also key — aim for 2.5L of water today!"
    elif any(w in msg for w in ['workout','exercise','training','gym','muscle']):
        reply = "Great work on your **Upper Body Push** session today! For muscle recovery, make sure to get **7-8 hours of sleep** tonight. Your next session should focus on pulling movements to balance your training. Consider adding **protein within 30 minutes** after your workout!"
    elif any(w in msg for w in ['rest','recovery','sleep','tired']):
        reply = "Recovery is just as important as training! You have trained **3 days in a row**, so Thursday is the perfect rest day. Active recovery like light walking or stretching helps muscles repair faster. Make sure you are getting **8 hours of sleep** for optimal gains!"
    elif any(w in msg for w in ['weight','lose','gain','fat','bulk']):
        reply = "For your goals, **consistency is key**! Make sure your calorie intake matches your target — you are at 1460 of 1800 kcal today. Focus on **high protein foods** to preserve muscle while managing weight. Track every meal using the scanner for best results!"
    elif any(w in msg for w in ['protein','carb','fat','macro']):
        reply = "Your **macros today** look well balanced! Protein is at 82g which is excellent for muscle recovery. Try to keep carbs around 160-180g for sustained energy. **Healthy fats** from avocado, nuts, or olive oil will support hormone health!"
    elif any(w in msg for w in ['water','hydrat']):
        reply = "You are at **1.5L of 2.5L** water target today! Proper hydration improves energy, focus, and workout performance. Try drinking a glass of water before each meal — it also helps with appetite control. **Aim to finish your 2.5L before 8pm!**"
    else:
        reply = "Great question! As your **Vitality AI coach**, I recommend focusing on consistency with your nutrition and training. You are doing well with your meals today — keep tracking and stay hydrated. Remember, **small daily improvements** lead to big long-term results!"
    
    return jsonify({"reply": reply})

@app.route('/api/scan', methods=['POST'])
def scan_food():
    data = request.json
    query = data.get('food', '').lower()
    for key, food in FOOD_DB.items():
        if key in query:
            return jsonify(food)
    import random
    return jsonify(random.choice(list(FOOD_DB.values())))

@app.route('/api/exercises')
def get_exercises():
    muscle = request.args.get('muscle', '')
    if muscle and muscle != 'All':
        filtered = [e for e in EXERCISES if e['muscle'] == muscle]
    else:
        filtered = EXERCISES
    return jsonify(filtered)

if __name__ == '__main__':
    print("\n" + "="*50)
    print("  VITALITY AI - Python Flask App")
    print("  Open: http://localhost:5000")
    print("="*50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
